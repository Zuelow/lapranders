import React from 'react';
import { Users, Heart, Shield } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-gray-900 dark:text-white">Om LAP Aalborg</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            LAP Aalborg er uafhængig af partipolitiske, økonomiske, behandlingsmæssige og religiøse interesser.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Users className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">En frivillig forening</h3>
            <p className="text-gray-600 dark:text-gray-300">
              LAP Aalborg er en frivillig forening, der finansieres gennem medlemskontingenter, bidrag og projektmidler. Vi har omkring 50 medlemmer i Nordjylland-regionen.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Heart className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Støtte og Fællesskab</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Vi har tæt kontakt til Psykiatriens hus, hvor der er to fastansatte og to peer medarbejdere. I psykiatriens hus kan alle komme ind fra gaden.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Shield className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Interessevaretagelse</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Interessevaretagelse er et centralt element i LAP Aalborg arbejde. Vi arbejder aktivt for at sikre, at mennesker med psykiske lidelser får en stærk stemme.
            </p>
          </div>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-3xl">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Formanden Signe Seiersen udtaler:</h3>
            <blockquote className="text-lg text-gray-600 dark:text-gray-300 italic">
              "Vi er rigtig glade for den positive udvikling i foreningen. Det styrker vores muligheder for at gøre en forskel for mennesker med psykiske lidelser i lokalområdet. Vores mål er at skabe et inkluderende fællesskab og give en stemme til en gruppe, der ofte står alene."
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}