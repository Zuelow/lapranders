import React from 'react';

export function Activities() {
  const activities = [
    {
      title: 'Samarbejde med Psykiatriens Hus',
      description: 'Vi har et tæt samarbejde med Psykiatriens Hus, hvor to fastansatte og to Peer support medarbejdere står klar til at hjælpe alle, der kommer ind fra gaden',
      image: 'https://images.unsplash.com/photo-1577563908411-5077b6dc7624?auto=format&fit=crop&q=80'
    },
    {
      title: 'Brugerindflydelse & Aktiviteter',
      description: 'Bestyrelsesmedlemmer bidrager med forskellige aktiviteter inden for forskellige områder i livet, tilpasset medlemmernes ønsker og behov',
      image: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80'
    }
  ];

  return (
    <section id="activities" className="py-20 bg-white dark:bg-gray-900">
      <div className="section-container">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-gray-900 dark:text-white">Vores Aktiviteter</h2>
        <p className="text-xl text-center text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
          Aktiviteterne i LAP Aalborg spænder vidt - fra afholdelse af sociale arrangementer og debatmøder til rådgivning, interessevaretagelse og opsøgende arbejde rettet mod sårbare borgere. Bestyrelsen har desuden iværksat flere nye initiativer.
        </p>
        <div className="grid md:grid-cols-2 gap-8">
          {activities.map((activity, index) => (
            <div key={index} className="group cursor-pointer animate-fade-in" style={{ animationDelay: `${index * 150}ms` }}>
              <div className="relative overflow-hidden rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300">
                <img
                  src={activity.image}
                  alt={activity.title}
                  className="w-full h-72 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-black/20 group-hover:from-black transition-colors" />
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <h3 className="text-2xl font-medium text-white mb-3">{activity.title}</h3>
                  <p className="text-white/90">{activity.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}