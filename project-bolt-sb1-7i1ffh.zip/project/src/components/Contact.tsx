import React, { useState } from 'react';
import { Mail, Facebook, AlertCircle, X, User, Phone, AtSign } from 'lucide-react';
import emailjs from '@emailjs/browser';
import { toast } from 'react-hot-toast';

// Initialize EmailJS with the correct public key
emailjs.init("yzp_vnUFUPM8Sw27_");

interface FormErrors {
  from_name?: string;
  user_email?: string;
  phone_number?: string;
  subject?: string;
  message?: string;
  city?: string;
  postal_code?: string;
}

export function Contact() {
  const [formData, setFormData] = useState({
    from_name: '',
    user_email: '',
    phone_number: '',
    subject: '',
    message: '',
    city: '',
    postal_code: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const contactInfo = [
    {
      title: 'Formand',
      name: 'Signe Seiersen',
      email: 'signe.s@mail1.stofanet.dk',
      phone: '50 59 38 14'
    },
    {
      title: 'Næstformand',
      name: 'Vita Willemoes Holst',
      email: 'zavigen@gmail.com'
    },
    {
      title: 'Kasserer',
      name: 'Michael Jochimsen',
      email: 'micjoc@outlook.dk'
    },
    {
      title: 'Suppleant',
      name: 'Anne Marie Nielsen',
      email: 'riemjensen@gmail.com'
    },
    {
      title: 'Suppleant',
      name: 'Torben Nørnberg Gade'
    }
  ];

  const validateForm = () => {
    const newErrors: FormErrors = {};

    if (!formData.from_name.trim()) {
      newErrors.from_name = 'Navn er påkrævet';
    } else if (formData.from_name.length < 2) {
      newErrors.from_name = 'Navn skal være mindst 2 tegn';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.user_email.trim()) {
      newErrors.user_email = 'Email er påkrævet';
    } else if (!emailRegex.test(formData.user_email)) {
      newErrors.user_email = 'Indtast venligst en gyldig email';
    }

    if (formData.phone_number && !/^[+\d\s-]{8,}$/.test(formData.phone_number)) {
      newErrors.phone_number = 'Indtast venligst et gyldigt telefonnummer';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Emne er påkrævet';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Besked er påkrævet';
    } else if (formData.message.length < 10) {
      newErrors.message = 'Beskeden skal være mindst 10 tegn';
    }

    if (!formData.city.trim()) {
      newErrors.city = 'By er påkrævet';
    }

    const postalCodeRegex = /^\d{4}$/;
    if (!formData.postal_code.trim()) {
      newErrors.postal_code = 'Postnummer er påkrævet';
    } else if (!postalCodeRegex.test(formData.postal_code)) {
      newErrors.postal_code = 'Indtast venligst et gyldigt postnummer (4 cifre)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      setShowConfirmation(true);
    } else {
      const allTouched = Object.keys(formData).reduce((acc, key) => {
        acc[key] = true;
        return acc;
      }, {} as Record<string, boolean>);
      setTouched(allTouched);
    }
  };

  const handleConfirmedSubmit = async () => {
    setIsSubmitting(true);
    setShowConfirmation(false);

    try {
      await emailjs.send(
        'service_m4aiao6',
        'template_y3tqrmb',
        formData,
        'yzp_vnUFUPM8Sw27_'
      );
      
      toast.success('Tak for din besked! Vi vender tilbage hurtigst muligt.');
      setFormData({
        from_name: '',
        user_email: '',
        phone_number: '',
        subject: '',
        message: '',
        city: '',
        postal_code: ''
      });
      setTouched({});
    } catch (error) {
      console.error('EmailJS Error:', error);
      toast.error('Der opstod en fejl. Prøv venligst igen.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (touched[name]) {
      validateForm();
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name } = e.target;
    setTouched(prev => ({
      ...prev,
      [name]: true
    }));
    validateForm();
  };

  return (
    <section id="contact" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="section-container">
        <div className="text-center mb-16">
          <Mail className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4 text-gray-900 dark:text-white">Kontakt Os Her</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-12">
            Hvis du ønsker at kontakte os eller har en kommentar, så udfyld venligst formularen nedenunder. Vi vil kontakte dig hurtigst muligt.
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto mb-16">
            {contactInfo.map((contact, index) => (
              <div key={index} className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow-sm hover:shadow-md transition-all">
                <h3 className="font-semibold text-red-600 mb-2">{contact.title}</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 justify-center">
                    <User className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    <span className="text-gray-800 dark:text-gray-200">{contact.name}</span>
                  </div>
                  {contact.email && (
                    <div className="flex items-center gap-2 justify-center">
                      <AtSign className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                      <a 
                        href={`mailto:${contact.email}`}
                        className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors"
                      >
                        {contact.email}
                      </a>
                    </div>
                  )}
                  {contact.phone && (
                    <div className="flex items-center gap-2 justify-center">
                      <Phone className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                      <a 
                        href={`tel:${contact.phone.replace(/\s/g, '')}`}
                        className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors"
                      >
                        {contact.phone}
                      </a>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="from_name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Dit navn *
                </label>
                <input
                  type="text"
                  id="from_name"
                  name="from_name"
                  value={formData.from_name}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.from_name && errors.from_name 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.from_name && errors.from_name && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.from_name}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="user_email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Din e-mail *
                </label>
                <input
                  type="email"
                  id="user_email"
                  name="user_email"
                  value={formData.user_email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.user_email && errors.user_email 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.user_email && errors.user_email && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.user_email}
                  </p>
                )}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="phone_number" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Telefon (valgfri)
                </label>
                <input
                  type="tel"
                  id="phone_number"
                  name="phone_number"
                  value={formData.phone_number}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.phone_number && errors.phone_number 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.phone_number && errors.phone_number && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.phone_number}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Emne *
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.subject && errors.subject 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.subject && errors.subject && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.subject}
                  </p>
                )}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="city" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  By *
                </label>
                <input
                  type="text"
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.city && errors.city 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.city && errors.city && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.city}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="postal_code" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Postnummer *
                </label>
                <input
                  type="text"
                  id="postal_code"
                  name="postal_code"
                  value={formData.postal_code}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    touched.postal_code && errors.postal_code 
                      ? 'border-red-500 focus:ring-red-500' 
                      : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                  } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                  disabled={isSubmitting}
                />
                {touched.postal_code && errors.postal_code && (
                  <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.postal_code}
                  </p>
                )}
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Besked *
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                onBlur={handleBlur}
                rows={4}
                className={`w-full px-4 py-2 rounded-lg border ${
                  touched.message && errors.message 
                    ? 'border-red-500 focus:ring-red-500' 
                    : 'border-gray-300 dark:border-gray-600 focus:ring-red-500'
                } focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white`}
                disabled={isSubmitting}
              />
              {touched.message && errors.message && (
                <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.message}
                </p>
              )}
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                className="bg-red-600 text-white px-8 py-3 rounded-full hover:bg-red-700 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={isSubmitting}
              >
                <Mail className="w-5 h-5" />
                {isSubmitting ? 'Sender...' : 'Send Besked'}
              </button>
            </div>
          </form>

          {showConfirmation && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md mx-4">
                <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
                  Bekræft afsendelse
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  Er du sikker på, at du vil sende denne besked?
                </p>
                <div className="flex justify-end gap-4">
                  <button
                    onClick={() => setShowConfirmation(false)}
                    className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 transition-colors"
                  >
                    Annuller
                  </button>
                  <button
                    onClick={handleConfirmedSubmit}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Ja, send besked
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">
              Sociale Medier
            </h3>
            <a
              href="https://www.facebook.com/profile.php?id=61568752157636"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors"
            >
              <Facebook className="w-6 h-6" />
              <span>Følg os på Facebook</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}