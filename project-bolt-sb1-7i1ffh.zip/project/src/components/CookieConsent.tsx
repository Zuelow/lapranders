import React, { useState, useEffect } from 'react';
import { Cookie, X } from 'lucide-react';

export function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false);

  useEffect(() => {
    // Check if user has already consented
    const hasConsented = localStorage.getItem('cookieConsent');
    if (!hasConsented) {
      setShowConsent(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'true');
    setShowConsent(false);
  };

  const handleReject = () => {
    localStorage.setItem('cookieConsent', 'false');
    setShowConsent(false);
  };

  if (!showConsent) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex items-center gap-3 flex-shrink-0">
            <Cookie className="w-6 h-6 text-red-600" />
            <h3 className="text-lg font-semibold">Cookiepolitik</h3>
          </div>
          
          <p className="text-gray-600 flex-grow">
            Vi bruger cookies til at analysere vores trafik og forbedre din brugeroplevelse. 
            Ved at fortsætte accepterer du vores brug af cookies. 
            Du kan altid tilbagekalde dit samtykke ved at slette dine cookies i din browser.
          </p>

          <div className="flex items-center gap-4 flex-shrink-0">
            <button
              onClick={handleReject}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Afvis
            </button>
            <button
              onClick={handleAccept}
              className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Acceptér
            </button>
          </div>

          <button
            onClick={handleReject}
            className="absolute top-4 right-4 md:hidden text-gray-400 hover:text-gray-600"
            aria-label="Luk cookie besked"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 text-sm text-gray-500">
          <p>
            Læs mere om vores{' '}
            <a
              href="https://www.lap.dk/laps-privatlivspolitik/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-600 hover:text-red-700 underline"
            >
              privatlivspolitik
            </a>
            {' '}og{' '}
            <a
              href="https://www.lap.dk/cookies/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-600 hover:text-red-700 underline"
            >
              cookiepolitik
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}