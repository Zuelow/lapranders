import React, { useState, useEffect } from 'react';
import { X, Upload, Image as ImageIcon, Trash2, ArrowUp, ArrowDown, ChevronLeft, ChevronRight, Save } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';

interface CarouselImage {
  url: string;
  alt: string;
  caption: string;
}

interface DesignSettings {
  carouselImages: CarouselImage[];
}

const defaultImages: CarouselImage[] = [
  {
    url: 'https://i.ibb.co/8bDrQK2/Dialogmoede-aalborg.jpg',
    alt: 'LAP Aalborg Dialogmøde',
    caption: 'LAP Aalborg Dialogmøde'
  },
  {
    url: 'https://images.unsplash.com/photo-1577563908411-5077b6dc7624?auto=format&fit=crop&q=80',
    alt: 'Mental Health Support',
    caption: 'Mental Sundhed'
  },
  {
    url: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80',
    alt: 'Community Meeting',
    caption: 'Fællesskabsmøde'
  },
  {
    url: 'https://images.unsplash.com/photo-1573497491765-dccce02b29df?auto=format&fit=crop&q=80',
    alt: 'Peer Support',
    caption: 'Peer Støtte'
  },
  {
    url: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80',
    alt: 'Group Therapy',
    caption: 'Gruppeterapi'
  }
];

export function DesignCustomizer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [images, setImages] = useState<CarouselImage[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDesignSettings();
  }, []);

  const fetchDesignSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('design_settings')
        .select('settings')
        .order('updated_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // No settings found, use defaults
          setImages(defaultImages);
        } else {
          throw error;
        }
      } else if (data) {
        setImages(data.settings.carouselImages || defaultImages);
      }
    } catch (error) {
      console.error('Error fetching design settings:', error);
      toast.error('Could not load design settings');
      setImages(defaultImages);
    } finally {
      setLoading(false);
    }
  };

  const saveDesignSettings = async () => {
    try {
      setSaving(true);

      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session?.user?.id) {
        throw new Error('Not authenticated');
      }

      const settings: DesignSettings = {
        carouselImages: images
      };

      const { error } = await supabase
        .from('design_settings')
        .upsert({
          settings,
          updated_by: sessionData.session.user.id,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast.success('Design settings saved successfully');
      onClose();
    } catch (error) {
      console.error('Error saving design settings:', error);
      toast.error('Could not save design settings');
    } finally {
      setSaving(false);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp']
    },
    maxSize: 2 * 1024 * 1024, // 2MB
    onDrop: async (acceptedFiles) => {
      try {
        const newImages = await Promise.all(
          acceptedFiles.map(async (file) => {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(
              `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/upload-image`,
              {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
                },
                body: formData,
              }
            );

            const data = await response.json();
            if (data.error) throw new Error(data.error);

            return {
              url: data.url,
              alt: file.name,
              caption: ''
            };
          })
        );

        setImages(prev => [...prev, ...newImages]);
        toast.success('Images uploaded successfully');
      } catch (error) {
        console.error('Upload error:', error);
        toast.error('Could not upload images');
      }
    }
  });

  const handleRemoveImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const moveImage = (index: number, direction: 'up' | 'down') => {
    const newImages = [...images];
    const newIndex = direction === 'up' ? index - 1 : index + 1;

    if (newIndex >= 0 && newIndex < newImages.length) {
      [newImages[index], newImages[newIndex]] = [newImages[newIndex], newImages[index]];
      setImages(newImages);
    }
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === images.length - 1 ? 0 : prev + 1
    );
  };

  const previousImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? images.length - 1 : prev - 1
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">Image Carousel</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Preview Carousel */}
          <div className="relative aspect-video mb-8 bg-black rounded-lg overflow-hidden">
            <img
              src={images[currentImageIndex].url}
              alt={images[currentImageIndex].alt}
              className="w-full h-full object-contain"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
              <p className="text-center">
                {images[currentImageIndex].caption || 'No caption'}
              </p>
            </div>
            <button
              onClick={previousImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
            <div className="absolute bottom-16 left-0 right-0 flex justify-center gap-2">
              {images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-2 h-2 rounded-full ${
                    index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Upload Area */}
          <div
            {...getRootProps()}
            className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center cursor-pointer hover:border-red-500 dark:hover:border-red-400 mb-8"
          >
            <input {...getInputProps()} />
            <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600 dark:text-gray-300">
              Drag & drop images here, or click to select files
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              Supported formats: JPG, PNG, WebP (max 2MB)
            </p>
          </div>

          {/* Image List */}
          <div className="space-y-4 max-h-[400px] overflow-y-auto">
            {images.map((image, index) => (
              <div 
                key={index}
                className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 flex items-center gap-4"
              >
                <div className="w-32 h-20 relative rounded-lg overflow-hidden">
                  <img
                    src={image.url}
                    alt={image.alt}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <input
                    type="text"
                    value={image.caption}
                    onChange={(e) => {
                      const newImages = [...images];
                      newImages[index].caption = e.target.value;
                      setImages(newImages);
                    }}
                    placeholder="Image caption"
                    className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => moveImage(index, 'up')}
                    disabled={index === 0}
                    className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 disabled:opacity-50"
                  >
                    <ArrowUp className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => moveImage(index, 'down')}
                    disabled={index === images.length - 1}
                    className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 disabled:opacity-50"
                  >
                    <ArrowDown className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleRemoveImage(index)}
                    className="p-2 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-700 p-4 flex justify-between gap-4">
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            {saving && 'Saving changes...'}
          </div>
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              onClick={saveDesignSettings}
              disabled={saving}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}