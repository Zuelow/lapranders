import React from 'react';
import { HelpCircle } from 'lucide-react';

export function FAQ() {
  const faqs = [
    {
      question: 'Hvad er LAP, og hvad laver foreningen?',
      answer: 'LAP Aalborg er en landsdækkende interesseorganisation, der arbejder for at styrke mennesker med psykiske lidelser.'
    },
    {
      question: 'Hvordan kan jeg blive medlem af LAP?',
      answer: 'Medlemskab af LAP Aalborg er åbent for alle, der har interesse i eller erfaring med psykiske udfordringer. Man kan melde sig ind direkte på foreningens hjemmeside eller ved at kontakte sekretariatet.'
    },
    {
      question: 'Hvilke aktiviteter og tilbud har LAP Aalborg?',
      answer: 'Foreningen arrangerer sociale arrangementer, netværksgrupper, kurser om recovery, kommunikation, job og meget mere. LAP driver også en rådgivning, hvor medlemmer kan få hjælp og sparring.'
    },
    {
      question: 'Hvordan kan LAP hjælpe mig?',
      answer: 'Uanset om du kæmper med psykiske problemer selv eller har en pårørende, kan LAP tilbyde rådgivning, fællesskab, interessevaretagelse og kompetenceudvikling, der kan understøtte din recovery-proces.'
    },
    {
      question: 'Hvordan kan jeg komme i kontakt med LAP Aalborg?',
      answer: 'Du kan kontakte LAP Aalborg telefonisk, pr. mail eller ved at opsøge foreningens aktiviteter og arrangementer i lokalområdet. Kontaktoplysninger findes på hjemmesiden.'
    },
    {
      question: 'Hvilke samarbejdspartnere har LAP Aalborg?',
      answer: 'LAP arbejder tæt sammen med kommuner, regioner, psykiatrien, socialpsykiatrien og andre organisationer for at sikre bedre vilkår og støtte til mennesker med psykiske lidelser.'
    }
  ];

  return (
    <section id="faq" className="py-20 bg-white dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-16">
          <HelpCircle className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-6 text-gray-900 dark:text-white">Ofte Stillede Spørgsmål</h2>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6 hover:shadow-md transition-shadow">
                <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">{faq.question}</h3>
                <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}