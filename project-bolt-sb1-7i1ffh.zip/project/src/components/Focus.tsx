import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Target, AlertCircle } from 'lucide-react';

export function Focus() {
  const { translations } = useLanguage();

  return (
    <section id="fokus" className="py-20 bg-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <Target className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{translations.focus.title}</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translations.focus.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {translations.focus.areas.map((area, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
            >
              <h3 className="text-xl font-bold mb-4 text-red-600">{area.title}</h3>
              <p className="text-gray-600 mb-6">{area.description}</p>
              {area.points && (
                <ul className="space-y-3">
                  {area.points.map((point, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-gray-700">
                      <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}