import React from 'react';
import { Mail, Phone, Facebook, ExternalLink, FileText, Radio, Tv, Newspaper, Globe, MapPin, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Footer() {
  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact');
    contactSection?.scrollIntoView({ behavior: 'smooth' });
  };

  const mainLinks = [
    { text: 'LAP Danmark', href: 'https://www.lap.dk', external: true },
    { text: 'Om LAP', href: 'https://www.lap.dk/om-lap/', external: true },
    { text: 'Organisation', href: 'https://www.lap.dk/organisation/', external: true },
    { text: 'Det mener LAP', href: 'https://www.lap.dk/det-mener-lap/', external: true },
    { text: 'Bliv medlem', href: 'https://www.lap.dk/bliv-medlem/', external: true },
    { text: 'Medlemsbladet', href: 'https://www.lap.dk/medlemsbladet/', external: true },
    { text: 'Kontakt', onClick: scrollToContact, external: false },
    { text: 'Admin', to: '/admin', icon: Lock, isRouterLink: true }
  ];

  const mediaLinks = [
    { text: 'LAP Radio', href: 'https://www.lap.dk/lap-radio/', icon: Radio },
    { text: 'LAP TV', href: 'https://www.lap.dk/lap-tv/', icon: Tv },
    { text: 'Udgivelser', href: 'https://www.lap.dk/udgivelser/', icon: FileText },
    { text: 'Nyhedsbrev', href: 'https://www.lap.dk/nyhedsbrev/', icon: Newspaper }
  ];

  const documents = [
    { text: 'LAPs Forretningsorden', href: 'https://www.lap.dk/forretningsorden/' },
    { text: 'LAPs Principprogram', href: 'https://www.lap.dk/laps-principprogram/' },
    { text: 'LAPs Vedtægter', href: 'https://www.lap.dk/vedtagter-for-lap-2/' },
    { text: 'LAPs Handlingsprogram', href: 'https://www.lap.dk/laps-handlingsprogram/' },
    { text: 'LAPs Privatlivspolitik', href: 'https://www.lap.dk/om-lap/privatlivspolitik/' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="flex justify-center mb-12">
          <a 
            href="https://www.lap.dk"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center hover:opacity-90 transition-opacity"
          >
            <img 
              src="https://www.lap.dk/wp-content/uploads/2020/12/lap-logo-1.svg" 
              alt="LAP Logo" 
              className="w-32 h-32 bg-white p-4 rounded-xl mb-4"
            />
            <span className="text-xl font-bold text-white">Landsforeningen Af nuværende og tidligere Psykiatribrugere</span>
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <h3 className="text-xl font-bold mb-6">Om LAP</h3>
            <p className="text-gray-400 mb-4">
              LAP er stiftet i 1999 som en landsdækkende interesseorganisation for nuværende og tidligere psykiatribrugere. Vi arbejder for at styrke vores medlemmers rettigheder og muligheder i samfundet.
            </p>
            <p className="text-sm text-gray-500">CVR: 25 01 26 15</p>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6">Navigation</h3>
            <ul className="space-y-3">
              {mainLinks.map((link, index) => (
                <li key={index}>
                  {link.onClick ? (
                    <button 
                      onClick={link.onClick}
                      className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                    >
                      {link.icon && <link.icon className="w-4 h-4" />}
                      {link.text}
                    </button>
                  ) : link.isRouterLink ? (
                    <Link 
                      to={link.to}
                      className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                    >
                      {link.icon && <link.icon className="w-4 h-4" />}
                      {link.text}
                    </Link>
                  ) : (
                    <a 
                      href={link.href}
                      target={link.external ? '_blank' : undefined}
                      rel={link.external ? 'noopener noreferrer' : undefined}
                      className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                    >
                      {link.icon && <link.icon className="w-4 h-4" />}
                      {link.external && <ExternalLink className="w-4 h-4" />}
                      {link.text}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6">LAP Medier & Ressourcer</h3>
            <ul className="space-y-3">
              {mediaLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <link.icon className="w-4 h-4" />
                    {link.text}
                  </a>
                </li>
              ))}
              <li className="pt-4">
                <h4 className="text-sm font-semibold text-gray-300 mb-2">LAP Dokumenter</h4>
                <ul className="space-y-2">
                  {documents.map((doc, index) => (
                    <li key={index}>
                      <a 
                        href={doc.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-400 hover:text-white transition-colors text-sm flex items-center gap-2"
                      >
                        <FileText className="w-4 h-4" />
                        {doc.text}
                      </a>
                    </li>
                  ))}
                </ul>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6">Kontakt LAP</h3>
            <ul className="space-y-4">
              <li>
                <div className="flex items-start gap-2">
                  <MapPin className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white">LAP</p>
                    <p className="text-gray-400">Store Glasvej 49</p>
                    <p className="text-gray-400">5000 Odense C</p>
                  </div>
                </div>
              </li>
              <li>
                <a 
                  href="tel:66194511" 
                  className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <Phone className="w-5 h-5 text-red-500" />
                  <div>
                    <span className="block">66 19 45 11</span>
                    <span className="text-sm text-gray-500">(mandag-torsdag kl. 10-14)</span>
                  </div>
                </a>
              </li>
              <li>
                <a 
                  href="mailto:lap@lap.dk"
                  className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <Mail className="w-5 h-5 text-red-500" />
                  lap@lap.dk
                </a>
              </li>
              <li>
                <a 
                  href="https://www.facebook.com/profile.php?id=61568752157636"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <Facebook className="w-5 h-5 text-red-500" />
                  Følg LAP Aalborg på Facebook
                </a>
              </li>
              <li>
                <a 
                  href="https://www.lap.dk/what-is-lap/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <Globe className="w-5 h-5 text-red-500" />
                  What is LAP? (English)
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm text-center md:text-left">
              © {new Date().getFullYear()} LAP - Landsforeningen Af nuværende og tidligere Psykiatribrugere. Alle rettigheder forbeholdes.
            </p>
            <div className="flex items-center gap-4">
              <a 
                href="https://www.lap.dk/om-lap/privatlivspolitik/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors text-sm"
              >
                LAPs Privatlivspolitik
              </a>
              <span className="text-gray-600">|</span>
              <Link 
                to="/cookies"
                className="text-gray-400 hover:text-white transition-colors text-sm"
              >
                LAPs Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}