import React from 'react';
import { Heart, ChevronDown } from 'lucide-react';
import { Button } from './ui/Button';

export function Hero() {
  const scrollToContactForm = () => {
    const contactForm = document.querySelector('#contact-form');
    contactForm?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToActivities = () => {
    const activitiesSection = document.querySelector('#activities');
    activitiesSection?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    aboutSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80"
          className="absolute inset-0 w-full h-full object-cover transform scale-105 animate-fade-in parallax"
          style={{ filter: 'brightness(0.5)' }}
          alt="LAP Aalborg hero image"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50" />
      </div>
      
      <div className="absolute top-0 left-0 z-10 p-4 md:p-6">
        <a href="https://lapaalborg.org" 
           className="flex flex-col sm:flex-row items-center glass-effect p-2 rounded-lg hover-scale">
          <img 
            src="https://www.lap.dk/wp-content/uploads/2020/12/lap-logo-1.svg" 
            alt="LAP Logo" 
            className="w-20 md:w-32 h-auto bg-white/90 p-2 rounded-lg mb-2 sm:mb-0"
          />
          <span className="ml-0 sm:ml-2 text-white text-lg md:text-xl font-semibold">Aalborg</span>
        </a>
      </div>

      <div className="relative flex flex-col items-center justify-center min-h-screen px-4">
        <div className="text-center max-w-3xl mx-auto mt-32 md:mt-16 space-y-8 animate-fade-in">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-6 animate-scale-in">
            Sammen står vi stærkere
          </h1>
          <p className="text-lg md:text-2xl mb-12 leading-relaxed text-white/90 animate-slide-in">
            LAP - et fællesskab med hjertet på rette sted. Sammen skaber vi håb og forandring for mennesker berørt af psykiske udfordringer. Gennem varme fællesskaber, gensidig støtte og meningsfulde aktiviteter arbejder vi for en bedre hverdag og stærkere rettigheder for alle, der har eller har haft kontakt med psykiatrien. Her møder du forståelse, omsorg og mennesker, der ved, hvad du går igennem. Sammen står vi stærkere.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button variant="primary" icon={Heart} onClick={scrollToContactForm}>
              Bliv medlem
            </Button>
            <Button variant="secondary" onClick={scrollToActivities}>
              Vores aktiviteter
            </Button>
          </div>
        </div>
        
        <button 
          onClick={scrollToAbout}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce cursor-pointer hover:text-rose-500 transition-colors"
          aria-label="Scroll to about section"
        >
          <ChevronDown className="w-8 h-8 text-white/80" />
        </button>
      </div>
    </div>
  );
}