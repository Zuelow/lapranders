import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Clock, ChevronDown, ChevronUp } from 'lucide-react';

interface HistorySection {
  title: string;
  content: string[];
}

export function History() {
  const { translations } = useLanguage();
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const historySections: Record<string, HistorySection> = {
    denmark: {
      title: 'Danmarks Historie',
      content: [
        'Vikingetiden (793-1066): En æra af ekspansion og handel, hvor danske vikinger rejste over hele Europa.',
        'Middelalderen: Kalmarunionen forenede Skandinavien under dansk ledelse.',
        'Renæssancen: Danmark blev en betydelig europæisk magt under Christian IV.',
        'Moderne tid: Udvikling af velfærdsstaten og demokratiske institutioner.'
      ]
    },
    faroeIslands: {
      title: 'Færøerne og Danmark',
      content: [
        'Første bosættelse i 800-tallet af norske vikinger.',
        'Del af det norske kongerige indtil 1380.',
        'Overført til dansk styre med Kalmarunionen.',
        'Hjemmestyre etableret i 1948, med fortsat tæt tilknytning til Danmark.'
      ]
    },
    germanDanish: {
      title: 'Dansk-Tyske Relationer',
      content: [
        'Slesvig-holstenske hertugdømmer: Århundreders sameksistens.',
        'Krigene i 1848-50 og 1864: Afgørende øjeblikke i dansk historie.',
        'Genforeningen i 1920: Nordslesvig bliver dansk igen.',
        'Moderne samarbejde: Tæt kulturelt og økonomisk partnerskab.'
      ]
    },
    norwegianDanish: {
      title: 'Norge-Danmark Unionen',
      content: [
        'Kalmarunionen 1380-1536: Forening af de nordiske riger.',
        'Danmark-Norge 1536-1814: 278 års fælles historie.',
        'Kulturel guldalder: Fælles litterær og kunstnerisk blomstring.',
        'Kristiania (Oslo): Centrum for dansk-norsk administration.'
      ]
    },
    greenland: {
      title: 'Grønland og Danmark',
      content: [
        'Hans Egedes ankomst i 1721: Begyndelsen på dansk tilstedeværelse.',
        'Kolonitiden: Udvikling af handel og mission.',
        'Hjemmestyre i 1979: Øget grønlandsk selvbestemmelse.',
        'Selvstyre i 2009: Ny æra i dansk-grønlandske relationer.'
      ]
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <section id="historie" className="py-20 bg-gray-50">
      <div className="section-container">
        <div className="text-center mb-16">
          <Clock className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{translations.history.title}</h2>
          <p className="text-xl text-gray-600">{translations.history.subtitle}</p>
        </div>

        <div className="max-w-3xl mx-auto space-y-6">
          {Object.entries(historySections).map(([key, section]) => (
            <div 
              key={key}
              className="bg-white rounded-2xl shadow-md overflow-hidden"
            >
              <button
                onClick={() => toggleSection(key)}
                className="w-full px-6 py-4 flex justify-between items-center hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-xl font-semibold text-gray-800">{section.title}</h3>
                {expandedSection === key ? (
                  <ChevronUp className="w-6 h-6 text-gray-500" />
                ) : (
                  <ChevronDown className="w-6 h-6 text-gray-500" />
                )}
              </button>
              {expandedSection === key && (
                <div className="px-6 pb-6">
                  <ul className="space-y-4">
                    {section.content.map((text, index) => (
                      <li key={index} className="text-gray-600 leading-relaxed">
                        {text}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}