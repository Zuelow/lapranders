import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Users } from 'lucide-react';

export function Join() {
  const { translations } = useLanguage();

  return (
    <section id="deltag" className="py-20 bg-red-600 text-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <Users className="w-12 h-12 text-white mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{translations.join.title}</h2>
          <p className="text-xl text-white/90">{translations.join.subtitle}</p>
        </div>

        <div className="max-w-md mx-auto">
          <form className="space-y-6">
            <div>
              <input
                type="text"
                placeholder="Navn"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Email"
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-white text-red-600 py-4 rounded-lg font-bold text-lg hover:bg-red-100 transition-colors"
            >
              {translations.join.cta}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}