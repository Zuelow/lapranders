import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ShoppingBag } from 'lucide-react';

export function Merchandise() {
  const { translations } = useLanguage();

  return (
    <section id="merchandise" className="py-20 bg-gray-50">
      <div className="section-container">
        <div className="text-center mb-16">
          <ShoppingBag className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{translations.merchandise.title}</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {translations.merchandise.products.map((product, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
            >
              <div className="aspect-square bg-gray-100 rounded-2xl mb-6" />
              <h3 className="text-xl font-bold mb-2">{product.title}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <p className="text-red-600 font-bold">{product.price}</p>
              <button className="mt-4 w-full bg-red-600 text-white py-3 rounded-full hover:bg-red-700 transition-colors">
                Køb nu
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}