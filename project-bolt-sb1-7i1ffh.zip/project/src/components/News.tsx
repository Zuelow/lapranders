import React from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

const newsArticles = [
  {
    id: '1',
    title: 'Velkommen til LAP Aalborg',
    content: 'Vi er glade for at kunne byde velkommen til LAP Aalborgs nye hjemmeside! Her vil du kunne finde information om vores aktiviteter, nyheder og meget mere. Vi arbejder konstant på at forbedre vores tilbud og services til vores medlemmer.',
    date: new Date().toISOString(),
    author: { username: 'LAP Aalborg' }
  }
];

export function News() {
  return (
    <section id="news" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-gray-900 dark:text-white">Nyheder</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
            Hold dig opdateret med de seneste nyheder fra LAP Aalborg
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {newsArticles.map((article) => (
            <article 
              key={article.id}
              className="bg-white dark:bg-gray-800 rounded-3xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="flex items-center gap-4 text-gray-500 dark:text-gray-400 mb-4">
                  <span>
                    {format(new Date(article.date), 'd. MMMM yyyy', { locale: da })}
                  </span>
                  <span>{article.author.username}</span>
                </div>

                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  {article.title}
                </h3>

                <div className="prose dark:prose-invert max-w-none">
                  <div className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line">
                    {article.content}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}