import React from 'react';
import { Building, Users, Target } from 'lucide-react';

export function Organization() {
  return (
    <section id="organization" className="py-20 bg-white dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6 text-gray-900 dark:text-white">LAP Aalborg Organisering</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            LAP Aalborg er den regionale afdeling af Landsforeningen af nuværende og tidligere psykiatribrugere i Nordjylland, Danmark.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Building className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Brugerdrevet Interesseorganisation</h3>
            <p className="text-gray-600 dark:text-gray-300">
              LAP Aalborg er en regional afdeling af den nationale LAP-organisation, som er en brugerledet interesseorganisation for mennesker med psykiske lidelser og vi dækker hele nordjylland.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Users className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Støtte og Rådgivning</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Organisationen driver støttegrupper, yder peer-to-peer rådgivning og arbejder på at påvirke den regionale psykiatripolitik og -praksis.
            </p>
          </div>

          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
            <Target className="w-12 h-12 text-red-600 mb-6" />
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Fokus på Rettigheder og Behov</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Centrale prioriteter for LAP Aalborg er at forbedre adgangen til lokalbaserede psykiatriske tilbud, øge beskæftigelsesmuligheder og udvide peer support-programmer.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}