import React from 'react';
import { HeartHandshake, Phone, ArrowRight } from 'lucide-react';
import { InfoCard } from './ui/InfoCard';

export function SubstanceSupport() {
  const supportCards = [
    {
      icon: HeartHandshake,
      title: 'Vejledning til Hjælp',
      description: 'Vi hjælper dig med at finde den rette professionelle støtte og behandling. Vi kan guide dig til de relevante tilbud i sundhedssystemet og sociale indsatser.'
    },
    {
      icon: Phone,
      title: 'Akut Henvisning',
      description: 'Vi kan henvise dig til akutte hjælpetilbud og behandlingscentre. Vi samarbejder med professionelle aktører, der er specialiserede i rusmiddelbehandling.'
    },
    {
      icon: ArrowRight,
      title: 'Den Rette Vej Frem',
      description: 'Vi hjælper dig med at navigere i systemet og finder de rette tilbud til dig. Vi støtter dig i at tage det første skridt mod professionel hjælp.'
    }
  ];

  return (
    <section id="substance-support" className="py-20 bg-lap-gold/10">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="section-title text-lap-navy">
            Hjælp ved Rusmiddelproblemer
          </h2>
          <p className="section-description text-lap-navy/80 mb-8">
            Hos LAP Aalborg forstår vi, at rusmiddelproblemer kan være komplekse og ofte hænger sammen med psykiske udfordringer. 
            Vi hjælper dig med at finde den rette professionelle støtte og behandling.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {supportCards.map((card, index) => (
            <InfoCard
              key={index}
              icon={card.icon}
              title={card.title}
              description={card.description}
            />
          ))}
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-lg">
          <h3 className="text-xl font-semibold text-lap-navy mb-6">
            Sådan Hjælper Vi Dig Videre
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-medium text-lap-navy mb-4">Vi Kan Guide Dig Til:</h4>
              <ul className="space-y-3 text-lap-navy/80">
                <li>• Professionelle behandlingscentre</li>
                <li>• Kommunale misbrugscentre</li>
                <li>• Akutte hjælpetilbud</li>
                <li>• Støttegrupper og netværk</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-lap-navy mb-4">Vores Rolle:</h4>
              <ul className="space-y-3 text-lap-navy/80">
                <li>• Hjælp til at finde rette behandlingstilbud</li>
                <li>• Støtte i kontakt med sundhedssystemet</li>
                <li>• Vejledning om forskellige behandlingsmuligheder</li>
                <li>• Brobygger til professionel hjælp</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}