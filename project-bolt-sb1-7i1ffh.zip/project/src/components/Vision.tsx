import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Eye, CheckCircle } from 'lucide-react';

export function Vision() {
  const { translations } = useLanguage();

  return (
    <section id="vision" className="py-20 bg-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <Eye className="w-12 h-12 text-red-600 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{translations.vision.title}</h2>
          <p className="text-xl text-gray-600">{translations.vision.subtitle}</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {translations.vision.points.map((point, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
            >
              <CheckCircle className="w-8 h-8 text-red-600 mb-4" />
              <p className="text-lg text-gray-800">{point}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}