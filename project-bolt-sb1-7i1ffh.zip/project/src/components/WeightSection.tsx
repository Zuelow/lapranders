import React from 'react';
import { Scale, Heart, Brain } from 'lucide-react';
import { InfoCard } from './ui/InfoCard';

export function WeightSection() {
  const infoCards = [
    {
      icon: Scale,
      title: 'Medicinrelateret Vægtøgning',
      description: 'Mange psykofarmaka kan påvirke stofskiftet og appetitten, hvilket kan føre til vægtøgning. Dette er en almindelig bivirkning, som kan påvirke både fysisk og mental trivsel.'
    },
    {
      icon: Heart,
      title: 'Sundhed & Velvære',
      description: 'Vi tilbyder støtte og vejledning om, hvordan du kan håndtere vægtøgning i forbindelse med din medicinske behandling, samtidig med at du opretholder en sund livsstil.'
    },
    {
      icon: Brain,
      title: 'Helhedsorienteret Tilgang',
      description: 'Gennem vores netværksgrupper deler vi erfaringer og strategier til at håndtere medicinrelaterede udfordringer, herunder vægtøgning, på en konstruktiv og støttende måde.'
    }
  ];

  return (
    <section id="weight-management" className="py-20 bg-white">
      <div className="section-container">
        <div className="text-center mb-16">
          <h2 className="section-title text-lap-navy">
            Medicinrelateret Vægtøgning
          </h2>
          <p className="section-description text-lap-navy/80 mb-8">
            At håndtere vægtøgning i forbindelse med psykiatrisk medicin kan være en udfordring. 
            Hos LAP Aalborg forstår vi denne problematik og tilbyder støtte og fællesskab.
          </p>
          <p className="text-lg text-lap-navy/70 max-w-3xl mx-auto">
            Vi ved, at medicinrelateret vægtøgning kan påvirke både dit fysiske og psykiske velbefindende. 
            Gennem vores netværk kan du møde andre i samme situation og dele erfaringer om, 
            hvordan man bedst håndterer denne udfordring.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {infoCards.map((card, index) => (
            <InfoCard
              key={index}
              icon={card.icon}
              title={card.title}
              description={card.description}
            />
          ))}
        </div>

        <div className="mt-16 bg-lap-navy/5 p-8 rounded-3xl">
          <h3 className="text-xl font-semibold text-lap-navy mb-4">
            Vores Tilbud og Støtte
          </h3>
          <ul className="space-y-4 text-lap-navy/80">
            <li className="flex items-start gap-2">
              • Netværksgrupper hvor du kan dele erfaringer med andre
            </li>
            <li className="flex items-start gap-2">
              • Information om kost og motion tilpasset din situation
            </li>
            <li className="flex items-start gap-2">
              • Støtte til dialog med sundhedspersonale om medicinering
            </li>
            <li className="flex items-start gap-2">
              • Aktiviteter der fremmer både fysisk og mental sundhed
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}