import React, { useEffect } from 'react';
import { toast } from 'react-hot-toast';

export function WelcomeNotification() {
  useEffect(() => {
    // Check if this is the first visit
    const hasVisited = localStorage.getItem('hasVisited');
    
    if (!hasVisited) {
      // Show welcome toast
      toast('Velkommen til LAP Aalborg! 👋', {
        icon: '👋',
        duration: 5000,
        style: {
          background: '#1a365d',
          color: '#fff',
          fontSize: '1.1rem',
          padding: '16px 24px',
          borderRadius: '12px',
        },
      });
      
      // Set visited flag
      localStorage.setItem('hasVisited', 'true');
    }
  }, []);

  return null;
}