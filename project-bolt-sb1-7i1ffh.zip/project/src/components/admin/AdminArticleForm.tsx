import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Editor } from '@tinymce/tinymce-react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { AlertTriangle, Save, Image as ImageIcon, X, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';

interface FormData {
  title: string;
  content: string;
  author_id: string;
  category_id: string;
  tags: string[];
  status: 'draft' | 'published';
  publication_date: string;
}

interface User {
  id: string;
  username: string;
  full_name: string;
}

interface Category {
  id: string;
  name: string;
}

export function AdminArticleForm() {
  const [users, setUsers] = useState<User[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [content, setContent] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const { register, handleSubmit, formState: { errors }, watch } = useForm<FormData>({
    defaultValues: {
      status: 'draft',
      publication_date: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm')
    }
  });

  useEffect(() => {
    fetchUsers();
    fetchCategories();
  }, []);

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, full_name')
        .order('username');

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Could not load users');
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name')
        .order('name');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Could not load categories');
    } finally {
      setLoading(false);
    }
  };

  const onDrop = async (acceptedFiles: File[]) => {
    setUploading(true);
    try {
      for (const file of acceptedFiles) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/upload-image`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            },
            body: formData,
          }
        );

        const data = await response.json();
        if (data.error) throw new Error(data.error);

        setImages(prev => [...prev, data.url]);
      }
      toast.success('Images uploaded successfully');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Could not upload images');
    } finally {
      setUploading(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif']
    },
    multiple: true
  });

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = async (data: FormData) => {
    try {
      const { data: adminData } = await supabase.auth.getSession();
      
      if (!adminData?.session?.user?.id) {
        throw new Error('You must be logged in to create articles');
      }

      // Check if user has admin role
      const { data: adminProfile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', adminData.session.user.id)
        .single();

      if (!adminProfile || adminProfile.role !== 'admin') {
        throw new Error('Only administrators can publish articles on behalf of others');
      }

      const articleData = {
        title: data.title,
        content,
        author_id: data.author_id,
        category_id: data.category_id || null,
        tags: data.tags,
        status: data.status,
        date: new Date(data.publication_date).toISOString(),
        images,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('news_articles')
        .insert([articleData]);

      if (error) throw error;
      
      toast.success('Article published successfully');
      
      // Log the admin action
      await supabase.from('audit_logs').insert([{
        user_id: adminData.session.user.id,
        action: 'create_article',
        table_name: 'news_articles',
        details: {
          author_id: data.author_id,
          article_title: data.title
        }
      }]);

    } catch (error: any) {
      toast.error(error.message || 'Could not publish article');
      console.error('Save error:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="mb-6">
        <div className="flex items-center gap-2 text-red-600 bg-red-50 p-4 rounded-lg">
          <AlertTriangle className="w-5 h-5" />
          <p>Du er ved at publicere denne artikel på vegne af en anden bruger. Denne handling vil blive logget i systemet.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Vælg forfatter *
          </label>
          <select
            {...register('author_id', { required: 'Forfatter er påkrævet' })}
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          >
            <option value="">Vælg forfatter</option>
            {users.map(user => (
              <option key={user.id} value={user.id}>
                {user.full_name} ({user.username})
              </option>
            ))}
          </select>
          {errors.author_id && (
            <p className="mt-1 text-sm text-red-600">{errors.author_id.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Titel *
          </label>
          <input
            {...register('title', { required: 'Titel er påkrævet' })}
            type="text"
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          />
          {errors.title && (
            <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Indhold *
          </label>
          <Editor
            apiKey="zy99ikscdpmjcvtvt1wrlp897o2xctzpb9ycy9sgz6bo7kfi"
            value={content}
            onEditorChange={(newContent) => setContent(newContent)}
            init={{
              height: 500,
              menubar: true,
              plugins: [
                'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
                'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
                'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'
              ],
              toolbar: 'undo redo | blocks | ' +
                'bold italic forecolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat | help',
              content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 16px; line-height: 1.5; }'
            }}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Kategori
          </label>
          <select
            {...register('category_id')}
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          >
            <option value="">Vælg kategori</option>
            {categories.map(category => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tags (kommasepareret)
          </label>
          <input
            {...register('tags')}
            type="text"
            placeholder="Eksempel: nyhed, event, møde"
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Billeder
          </label>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              isDragActive ? 'border-red-500 bg-red-50' : 'border-gray-300 hover:border-red-500'
            }`}
          >
            <input {...getInputProps()} />
            <ImageIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
            <p className="text-gray-600">
              {isDragActive
                ? 'Slip billederne her...'
                : 'Træk billeder hertil, eller klik for at vælge'}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Understøttede formater: JPG, JPEG, PNG, GIF
            </p>
          </div>

          {uploading && (
            <div className="mt-4 text-center text-gray-600">
              Uploader billeder...
            </div>
          )}

          {images.length > 0 && (
            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
              {images.map((url, index) => (
                <div key={index} className="relative group">
                  <img
                    src={url}
                    alt={`Uploaded ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-2 right-2 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Publiceringstidspunkt
            </label>
            <input
              {...register('publication_date')}
              type="datetime-local"
              className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              {...register('status')}
              className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
            >
              <option value="draft">Kladde</option>
              <option value="published">Publiceret</option>
            </select>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button
            type="submit"
            className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
          >
            <Save className="w-5 h-5" />
            Publicer som valgt bruger
          </button>
        </div>
      </form>
    </div>
  );
}