import React, { useState } from 'react';
import { FileText, Users, Settings, Shield, LayoutDashboard, BookOpen, Home, Moon, Sun, Image } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Link, useLocation } from 'react-router-dom';
import { UserAvatar } from './UserAvatar';
import { useTheme } from '../../contexts/ThemeContext';
import { DesignCustomizer } from './DesignCustomizer';

export function AdminNav() {
  const { signOut, user } = useAuth();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [showDesignCustomizer, setShowDesignCustomizer] = useState(false);
  
  const navItems = [
    { id: 'overview', label: 'Oversigt', icon: LayoutDashboard, path: '/admin' },
    { id: 'content', label: 'Indhold', icon: BookOpen, path: '/admin/content' },
    { id: 'users', label: 'Brugere', icon: Users, path: '/admin/users' },
    { id: 'security', label: 'Sikkerhed', icon: Shield, path: '/admin/security' },
    { id: 'settings', label: 'Indstillinger', icon: Settings, path: '/admin/settings' }
  ];

  return (
    <>
      <nav className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link
                to="/"
                className="inline-flex items-center px-4 py-2 border-b-2 border-transparent text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300"
              >
                <Home className="w-5 h-5 mr-2" />
                Tilbage til hjemmeside
              </Link>
              {navItems.map((item) => (
                <Link
                  key={item.id}
                  to={item.path}
                  className={`inline-flex items-center px-4 py-2 border-b-2 text-sm font-medium ${
                    location.pathname === item.path
                      ? 'border-red-500 text-red-600 dark:text-red-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-2" />
                  {item.label}
                </Link>
              ))}
            </div>
            
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowDesignCustomizer(true)}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              >
                <Image className="w-5 h-5 mr-2" />
                Design
              </button>
              <button
                onClick={toggleTheme}
                className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 rounded-lg"
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </button>
              {user?.id && (
                <div className="flex items-center gap-3">
                  <UserAvatar
                    userId={user.id}
                    avatarUrl={user.profile?.avatar_url}
                    username={user.profile?.username}
                    role={user.profile?.role}
                    lastLogin={user.profile?.last_login_at}
                    size="sm"
                    editable
                  />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {user.profile?.username || 'Bruger'}
                  </span>
                </div>
              )}
              <button
                onClick={() => signOut()}
                className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 px-3 py-2 rounded-md text-sm font-medium"
              >
                Log ud
              </button>
            </div>
          </div>
        </div>
      </nav>

      <DesignCustomizer 
        isOpen={showDesignCustomizer} 
        onClose={() => setShowDesignCustomizer(false)} 
      />
    </>
  );
}