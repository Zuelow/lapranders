import React, { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { NewsManager } from './NewsManager';
import { UserManager } from './UserManager';
import { Settings } from './Settings';
import { SecurityLogs } from './SecurityLogs';
import { SecurityDashboard } from './SecurityDashboard';
import { Activity, Users, FileText, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Stats {
  users: number;
  news: number;
  activities: number;
}

export function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({
    users: 0,
    news: 0,
    activities: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      // Get users count (excluding admin)
      const { count: usersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .neq('role', 'admin');

      // Get published news count
      const { count: newsCount } = await supabase
        .from('news_articles')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'published');

      // Get today's date at midnight
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Get tomorrow's date at midnight
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Count all security activities for today
      const { data: securityActivities, error: securityError } = await supabase
        .from('audit_logs')
        .select('id')
        .gte('created_at', today.toISOString())
        .lt('created_at', tomorrow.toISOString());

      if (securityError) throw securityError;

      // Count all login attempts for today
      const { data: loginActivities, error: loginError } = await supabase
        .from('login_history')
        .select('id')
        .gte('created_at', today.toISOString())
        .lt('created_at', tomorrow.toISOString());

      if (loginError) throw loginError;

      // Total activities is the sum of all security-related activities
      const totalActivities = (securityActivities?.length || 0) + (loginActivities?.length || 0);

      setStats({
        users: usersCount || 0,
        news: newsCount || 0,
        activities: totalActivities
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { label: 'Brugere', value: loading ? '...' : stats.users, icon: Users },
    { label: 'Nyheder', value: loading ? '...' : stats.news, icon: FileText },
    { label: 'Dagens Aktiviteter', value: loading ? '...' : stats.activities, icon: Activity },
  ];

  return (
    <>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3 mb-6">
        {statCards.map((stat) => (
          <div key={stat.label} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
                <p className="text-2xl font-semibold text-gray-900 dark:text-white">{stat.value}</p>
              </div>
              <stat.icon className="w-8 h-8 text-red-600" />
            </div>
          </div>
        ))}
      </div>
      <SecurityDashboard />
    </>
  );
}