import React, { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { Save, Image as ImageIcon, X, ArrowLeft } from 'lucide-react';
import { Editor } from '@tinymce/tinymce-react';

interface NewsFormData {
  title: string;
  content: string;
  date: string;
  status: 'draft' | 'published' | 'archived';
}

interface NewsEditorProps {
  article?: any;
  onClose: () => void;
}

export function NewsEditor({ article, onClose }: NewsEditorProps) {
  const [content, setContent] = useState(article?.content || '');
  const [images, setImages] = useState<string[]>(article?.images || []);
  const [uploading, setUploading] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<NewsFormData>({
    defaultValues: article ? {
      title: article.title,
      content: article.content,
      date: new Date(article.date).toISOString().split('T')[0],
      status: article.status
    } : {
      date: new Date().toISOString().split('T')[0],
      status: 'draft'
    }
  });

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setUploading(true);
    try {
      for (const file of acceptedFiles) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/upload-image`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            },
            body: formData,
          }
        );

        const data = await response.json();
        if (data.error) throw new Error(data.error);

        setImages(prev => [...prev, data.url]);
      }
      toast.success('Images uploaded successfully');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Could not upload images');
    } finally {
      setUploading(false);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif']
    },
    multiple: true
  });

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = async (data: NewsFormData) => {
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      
      if (!sessionData?.session?.user?.id) {
        throw new Error('You must be logged in to create articles');
      }

      const articleData = {
        title: data.title,
        content,
        date: new Date(data.date).toISOString(),
        status: data.status,
        images,
        author_id: sessionData.session.user.id,
        updated_at: new Date().toISOString()
      };

      const { error } = article
        ? await supabase
            .from('news_articles')
            .update(articleData)
            .eq('id', article.id)
        : await supabase
            .from('news_articles')
            .insert([articleData]);

      if (error) throw error;
      
      toast.success(article ? 'Article updated' : 'Article created');
      onClose();
    } catch (error: any) {
      toast.error(error.message || 'Could not save article');
      console.error('Save error:', error);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={onClose}
          className="text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold">
          {article ? 'Edit Article' : 'Create New Article'}
        </h2>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Title *
          </label>
          <input
            {...register('title', { required: 'Title is required' })}
            type="text"
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          />
          {errors.title && (
            <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Content *
          </label>
          <Editor
            apiKey="zy99ikscdpmjcvtvt1wrlp897o2xctzpb9ycy9sgz6bo7kfi"
            value={content}
            onEditorChange={(newContent) => setContent(newContent)}
            init={{
              height: 500,
              menubar: true,
              plugins: [
                'anchor', 'autolink', 'charmap', 'codesample', 'emoticons',
                'image', 'link', 'lists', 'media', 'searchreplace',
                'table', 'visualblocks', 'wordcount'
              ],
              toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
              content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 16px; line-height: 1.5; }',
              branding: false,
              promotion: false
            }}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date *
          </label>
          <input
            {...register('date', { required: 'Date is required' })}
            type="date"
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          />
          {errors.date && (
            <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <select
            {...register('status')}
            className="w-full px-4 py-2 rounded-lg border focus:ring-red-500 focus:border-red-500"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Images
          </label>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              isDragActive ? 'border-red-500 bg-red-50' : 'border-gray-300 hover:border-red-500'
            }`}
          >
            <input {...getInputProps()} />
            <ImageIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
            <p className="text-gray-600">
              {isDragActive
                ? 'Drop the images here...'
                : 'Drag & drop images here, or click to select'}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Supported formats: JPG, JPEG, PNG, GIF
            </p>
          </div>

          {uploading && (
            <div className="mt-4 text-center text-gray-600">
              Uploading images...
            </div>
          )}

          {images.length > 0 && (
            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
              {images.map((url, index) => (
                <div key={index} className="relative group">
                  <img
                    src={url}
                    alt={`Uploaded ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-2 right-2 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-gray-900"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting || uploading}
            className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            <Save className="w-5 h-5" />
            {isSubmitting ? 'Saving...' : 'Save Article'}
          </button>
        </div>
      </form>
    </div>
  );
}