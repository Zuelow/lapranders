import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { Eye, Edit, Trash2, Plus, X, UserPlus } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { NewsEditor } from './NewsEditor';
import { AdminArticleForm } from './AdminArticleForm';

interface NewsArticle {
  id: string;
  title: string;
  content: string;
  date: string;
  status: string;
  author_id: string;
  author: {
    username: string;
  } | null;
}

export function NewsManager() {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [showEditor, setShowEditor] = useState(false);
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [articleToDelete, setArticleToDelete] = useState<string | null>(null);

  useEffect(() => {
    fetchArticles();
  }, []);

  const fetchArticles = async () => {
    try {
      const { data, error } = await supabase
        .from('news_articles')
        .select(`
          id,
          title,
          content,
          date,
          status,
          author_id,
          author:profiles(username)
        `)
        .order('date', { ascending: false });

      if (error) throw error;
      setArticles(data || []);
    } catch (error) {
      console.error('Error fetching articles:', error);
      toast.error('Could not load articles');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    setArticleToDelete(id);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!articleToDelete) return;

    try {
      const { error } = await supabase
        .from('news_articles')
        .delete()
        .eq('id', articleToDelete);

      if (error) throw error;
      
      toast.success('Article deleted successfully');
      fetchArticles();
    } catch (error) {
      console.error('Error deleting article:', error);
      toast.error('Could not delete article');
    } finally {
      setShowDeleteConfirm(false);
      setArticleToDelete(null);
    }
  };

  const handleEdit = (article: NewsArticle) => {
    setSelectedArticle(article);
    setShowEditor(true);
    setShowAdminForm(false);
  };

  const handlePreview = (article: NewsArticle) => {
    setSelectedArticle(article);
    setShowPreview(true);
  };

  const handleCreateNew = () => {
    setSelectedArticle(null);
    setShowEditor(true);
    setShowAdminForm(false);
  };

  const handleCreateAsUser = () => {
    setSelectedArticle(null);
    setShowEditor(false);
    setShowAdminForm(true);
  };

  if (showEditor) {
    return <NewsEditor article={selectedArticle} onClose={() => setShowEditor(false)} />;
  }

  if (showAdminForm) {
    return <AdminArticleForm />;
  }

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Nyheder</h2>
        <div className="flex gap-4">
          <button
            onClick={handleCreateAsUser}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <UserPlus className="w-5 h-5" />
            Opret som anden bruger
          </button>
          <button
            onClick={handleCreateNew}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Opret ny artikel
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-4">Indlæser...</div>
      ) : articles.length === 0 ? (
        <div className="text-center py-4 text-gray-500">
          Ingen artikler at vise
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Titel
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Forfatter
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dato
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Handlinger
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {articles.map((article) => (
                <tr key={article.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {article.title}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      article.status === 'published'
                        ? 'bg-green-100 text-green-800'
                        : article.status === 'draft'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {article.status === 'published' ? 'Publiceret' : 
                       article.status === 'draft' ? 'Kladde' : 'Arkiveret'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {article.author?.username || 'LAP Aalborg'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {format(new Date(article.date), 'dd. MMMM yyyy', { locale: da })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => handlePreview(article)}
                      className="text-gray-600 hover:text-gray-900 mr-4"
                      title="Forhåndsvis"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleEdit(article)}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                      title="Rediger"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(article.id)}
                      className="text-red-600 hover:text-red-900"
                      title="Slet"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Bekræft sletning</h3>
            <p className="text-gray-600 mb-6">
              Er du sikker på, at du vil slette denne artikel? Denne handling kan ikke fortrydes.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setArticleToDelete(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Annuller
              </button>
              <button
                onClick={confirmDelete}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                Ja, slet artikel
              </button>
            </div>
          </div>
        </div>
      )}

      {showPreview && selectedArticle && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-bold">{selectedArticle.title}</h3>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="prose max-w-none">
              {selectedArticle.content.split('\n\n').map((paragraph, index) => (
                <p key={index} className="mb-4">{paragraph}</p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}