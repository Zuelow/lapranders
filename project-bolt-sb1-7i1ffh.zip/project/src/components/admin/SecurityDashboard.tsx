import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Shield, RefreshCw } from 'lucide-react';

interface IPEntry {
  ip_address: string;
  country_code?: string;
  last_seen: string;
  attempts: number;
  success_count: number;
  fail_count: number;
  total_activity: number;
}

export function SecurityDashboard() {
  const [ipData, setIpData] = useState<IPEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchIPData();
  }, []);

  const fetchCountryData = async (ip: string): Promise<{ ip: string; countryCode?: string }> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const response = await fetch(`https://ipapi.co/${ip}/json/`, {
        signal: controller.signal
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      clearTimeout(timeoutId);
      return { 
        ip, 
        countryCode: data.error ? undefined : data.country_code?.toLowerCase() 
      };
    } catch (error) {
      clearTimeout(timeoutId);
      console.warn(`Could not fetch country data for IP ${ip}:`, error);
      return { ip, countryCode: undefined };
    }
  };

  const fetchIPData = async () => {
    try {
      setLoading(true);
      setRefreshing(true);
      
      // Get today's date at midnight
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Get tomorrow's date at midnight
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Fetch login history entries for today
      const { data: loginHistory, error: loginError } = await supabase
        .from('login_history')
        .select('ip_address, created_at, success')
        .gte('created_at', today.toISOString())
        .lt('created_at', tomorrow.toISOString());

      if (loginError) throw loginError;

      // Fetch audit logs for today
      const { data: auditLogs, error: auditError } = await supabase
        .from('audit_logs')
        .select('ip_address, created_at')
        .gte('created_at', today.toISOString())
        .lt('created_at', tomorrow.toISOString());

      if (auditError) throw auditError;

      // Process and combine data
      const ipMap = new Map<string, IPEntry>();

      // Process login history
      loginHistory?.forEach(attempt => {
        if (!attempt.ip_address) return;

        const existing = ipMap.get(attempt.ip_address) || {
          ip_address: attempt.ip_address,
          last_seen: attempt.created_at,
          attempts: 0,
          success_count: 0,
          fail_count: 0,
          total_activity: 0
        };

        existing.attempts++;
        if (attempt.success) {
          existing.success_count++;
        } else {
          existing.fail_count++;
        }
        existing.total_activity = existing.success_count + existing.fail_count;

        if (new Date(attempt.created_at) > new Date(existing.last_seen)) {
          existing.last_seen = attempt.created_at;
        }

        ipMap.set(attempt.ip_address, existing);
      });

      // Process audit logs
      auditLogs?.forEach(log => {
        if (!log.ip_address) return;

        const existing = ipMap.get(log.ip_address) || {
          ip_address: log.ip_address,
          last_seen: log.created_at,
          attempts: 0,
          success_count: 0,
          fail_count: 0,
          total_activity: 0
        };

        existing.attempts++;
        existing.total_activity++;

        if (new Date(log.created_at) > new Date(existing.last_seen)) {
          existing.last_seen = log.created_at;
        }

        ipMap.set(log.ip_address, existing);
      });

      // Convert to array and sort by last seen
      const ipArray = Array.from(ipMap.values()).sort(
        (a, b) => new Date(b.last_seen).getTime() - new Date(a.last_seen).getTime()
      );

      // Fetch country data for each IP
      const countryPromises = ipArray.map(entry => fetchCountryData(entry.ip_address));
      const countryResults = await Promise.allSettled(countryPromises);

      // Add country codes to entries
      const enrichedData = ipArray.map((entry, index) => {
        const countryResult = countryResults[index];
        return {
          ...entry,
          country_code: countryResult.status === 'fulfilled' ? countryResult.value.countryCode : undefined
        };
      });

      setIpData(enrichedData);
      setError(null);
    } catch (error) {
      console.error('Error fetching security data:', error);
      setError('Kunne ikke indlæse sikkerhedsdata');
      toast.error('Kunne ikke indlæse sikkerhedsdata');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    fetchIPData();
  };

  if (error) {
    return (
      <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
        <div className="flex items-center gap-3 text-red-600">
          <Shield className="w-6 h-6" />
          <h2 className="text-xl font-semibold">{error}</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-red-600" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">IP Adresser og Aktivitet</h2>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
          Opdater
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Land
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                IP Adresse
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Sidst set
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Succes/Fejl
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Total aktivitet
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {ipData.map((entry, index) => (
              <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                <td className="px-6 py-4 whitespace-nowrap">
                  {entry.country_code ? (
                    <img
                      src={`https://flagcdn.com/24x18/${entry.country_code}.png`}
                      alt={`Flag for ${entry.country_code.toUpperCase()}`}
                      className="h-4 w-auto"
                      title={entry.country_code.toUpperCase()}
                    />
                  ) : (
                    <span className="text-gray-400 dark:text-gray-500">-</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap font-mono text-sm text-gray-900 dark:text-white">
                  {entry.ip_address}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {format(new Date(entry.last_seen), 'dd/MM/yyyy HH:mm', { locale: da })}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <span className="text-green-600 dark:text-green-400">{entry.success_count}</span>
                    <span className="text-gray-400 dark:text-gray-500">/</span>
                    <span className="text-red-600 dark:text-red-400">{entry.fail_count}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    entry.total_activity > 10
                      ? 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                      : entry.total_activity > 5
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                      : 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                  }`}>
                    {entry.total_activity}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}