import React from 'react';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { format } from 'date-fns';
import { Shield, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  details: any;
  ip_address: string;
  country_code?: string;
  created_at: string;
}

export function SecurityLogs() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchCountryData = async (ip: string): Promise<{ ip: string; countryCode?: string }> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

    try {
      // Try primary service
      const response = await fetch(`https://ipapi.co/${ip}/json/`, {
        signal: controller.signal
      });
      const data = await response.json();
      
      if (!data.error) {
        clearTimeout(timeoutId);
        return { ip, countryCode: data.country_code?.toLowerCase() };
      }

      // Try fallback service
      const fallbackResponse = await fetch(`https://ip-api.com/json/${ip}`, {
        signal: controller.signal
      });
      const fallbackData = await fallbackResponse.json();
      
      clearTimeout(timeoutId);
      return {
        ip,
        countryCode: fallbackData.status === 'success' ? fallbackData.countryCode?.toLowerCase() : undefined
      };
    } catch (error) {
      clearTimeout(timeoutId);
      console.warn(`Could not fetch country data for IP ${ip}:`, error);
      return { ip, countryCode: undefined };
    }
  };

  async function fetchLogs() {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      // Filter out logs with null IP addresses and get unique IPs
      const validLogs = (data || []).filter(log => log.ip_address);
      const uniqueIPs = [...new Set(validLogs.map(log => log.ip_address))];

      // Use Promise.allSettled to handle failed requests gracefully
      const countryDataResults = await Promise.allSettled(
        uniqueIPs.map(ip => fetchCountryData(ip))
      );

      // Create IP to country code mapping from successful results
      const ipCountryMap = Object.fromEntries(
        countryDataResults
          .filter((result): result is PromiseFulfilledResult<{ ip: string; countryCode?: string }> => 
            result.status === 'fulfilled'
          )
          .map(result => [result.value.ip, result.value.countryCode])
      );

      // Add country codes to logs
      const logsWithCountry = validLogs.map(log => ({
        ...log,
        country_code: ipCountryMap[log.ip_address]
      }));

      setLogs(logsWithCountry);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      toast.error('Could not load audit logs');
    } finally {
      setLoading(false);
    }
  }

  const handleDeleteAllLogs = async () => {
    setShowDeleteConfirm(true);
  };

  const confirmDeleteAllLogs = async () => {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (error) throw error;
      
      toast.success('All logs deleted successfully');
      setLogs([]);
    } catch (error) {
      console.error('Error deleting logs:', error);
      toast.error('Could not delete logs');
    } finally {
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-red-600" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Sikkerhedslog</h2>
        </div>
        <button
          onClick={handleDeleteAllLogs}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          <Trash2 className="w-5 h-5" />
          Slet alle logs
        </button>
      </div>

      {loading ? (
        <div className="text-center py-4 text-gray-600 dark:text-gray-300">Indlæser...</div>
      ) : logs.length === 0 ? (
        <div className="text-center py-4 text-gray-500 dark:text-gray-400">
          Ingen logs at vise
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Tidspunkt
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Handling
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Bruger
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Land / IP Adresse
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {format(new Date(log.created_at), 'dd/MM/yyyy HH:mm:ss')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {log.action}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {log.user_id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-2">
                      {log.country_code && (
                        <img
                          src={`https://flagcdn.com/24x18/${log.country_code}.png`}
                          alt={`Flag for ${log.country_code.toUpperCase()}`}
                          className="h-4 w-auto"
                          title={log.country_code.toUpperCase()}
                        />
                      )}
                      <span className="font-mono text-gray-900 dark:text-white">{log.ip_address}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Bekræft sletning</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Er du sikker på, at du vil slette alle sikkerhedslogs? Denne handling kan ikke fortrydes.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 transition-colors"
              >
                Annuller
              </button>
              <button
                onClick={confirmDeleteAllLogs}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                Ja, slet alle logs
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}