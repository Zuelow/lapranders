import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { User, Upload } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { format } from 'date-fns';

interface UserAvatarProps {
  userId: string;
  avatarUrl?: string | null;
  username?: string;
  role?: string;
  lastLogin?: string | null;
  size?: 'sm' | 'md' | 'lg';
  onAvatarUpdate?: (url: string) => void;
  editable?: boolean;
}

export function UserAvatar({ 
  userId, 
  avatarUrl, 
  username,
  role,
  lastLogin,
  size = 'md',
  onAvatarUpdate,
  editable = false 
}: UserAvatarProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  const handleAvatarUpload = async (file: File) => {
    try {
      // Create a unique filename
      const fileExt = file.name.split('.').pop()?.toLowerCase();
      const fileName = `${userId}-${Date.now()}.${fileExt}`;

      // Upload the file
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      // Update the user's profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', userId);

      if (updateError) throw updateError;

      // Clean up old avatar if it exists
      if (avatarUrl) {
        const oldFileName = avatarUrl.split('/').pop();
        if (oldFileName) {
          await supabase.storage
            .from('avatars')
            .remove([oldFileName]);
        }
      }

      onAvatarUpdate?.(publicUrl);
      toast.success('Avatar updated successfully');
    } catch (error: any) {
      console.error('Error uploading avatar:', error);
      toast.error(error.message || 'Could not upload avatar');
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    maxSize: 5242880, // 5MB
    multiple: false,
    disabled: !editable,
    onDrop: async (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        await handleAvatarUpload(acceptedFiles[0]);
      }
    }
  });

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  return (
    <div className="relative inline-block">
      <div
        {...(editable ? getRootProps() : {})}
        className={`relative rounded-full bg-gray-100 flex items-center justify-center overflow-hidden ${
          sizeClasses[size]
        } ${editable ? 'cursor-pointer hover:bg-gray-200 transition-colors' : ''}`}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {avatarUrl ? (
          <img
            src={avatarUrl}
            alt={`${username || 'User'}'s avatar`}
            className="w-full h-full object-cover"
          />
        ) : (
          <User className={`${iconSizes[size]} text-gray-400`} />
        )}
        
        {editable && (
          <>
            <input {...getInputProps()} />
            <div className={`absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity ${
              isDragActive ? 'opacity-100' : ''
            }`}>
              <Upload className="w-5 h-5 text-white" />
            </div>
          </>
        )}
      </div>

      {/* Tooltip positioned below */}
      {showTooltip && (role || lastLogin) && (
        <div className="absolute z-50 top-full left-1/2 transform -translate-x-1/2 mt-2 bg-gray-900 text-white text-sm rounded-lg py-2 px-3 whitespace-nowrap">
          {role && <div>Role: {role}</div>}
          {lastLogin && (
            <div>
              Last login: {format(new Date(lastLogin), 'dd/MM/yyyy HH:mm')}
            </div>
          )}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
        </div>
      )}
    </div>
  );
}