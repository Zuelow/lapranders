import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { User, Edit, Trash2, Lock, CheckCircle, XCircle, AlertTriangle, Upload } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { useAuth } from '../../hooks/useAuth';
import { useDropzone } from 'react-dropzone';

interface UserProfile {
  id: string;
  email: string;
  username: string;
  full_name: string;
  role: string;
  status: string;
  avatar_url: string | null;
  last_login_at: string;
  created_at: string;
}

interface EditFormData {
  full_name: string;
  role: string;
  status: string;
}

export function UserManager() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [userToReset, setUserToReset] = useState<UserProfile | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  const [pendingChanges, setPendingChanges] = useState<EditFormData | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Kunne ikke indlæse brugere');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (userProfile: UserProfile) => {
    if (userProfile.id === user?.id) {
      toast.error('Du kan ikke slette din egen konto');
      return;
    }
    setUserToDelete(userProfile);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!userToDelete) return;

    try {
      const { error } = await supabase.auth.admin.deleteUser(userToDelete.id);
      if (error) throw error;
      
      toast.success('Bruger slettet');
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Kunne ikke slette bruger');
    } finally {
      setShowDeleteConfirm(false);
      setUserToDelete(null);
    }
  };

  const handleResetPassword = (userProfile: UserProfile) => {
    setUserToReset(userProfile);
    setShowResetConfirm(true);
  };

  const confirmResetPassword = async () => {
    if (!userToReset) return;

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(userToReset.email, {
        redirectTo: `${window.location.origin}/admin/reset-password`
      });
      
      if (error) throw error;
      toast.success('Email til nulstilling af adgangskode sendt');
    } catch (error) {
      console.error('Error resetting password:', error);
      toast.error('Kunne ikke nulstille adgangskode');
    } finally {
      setShowResetConfirm(false);
      setUserToReset(null);
    }
  };

  const handleEdit = (userProfile: UserProfile) => {
    setEditingUser(userProfile);
    setShowEditModal(true);
  };

  const handleUpdateUser = async (formData: EditFormData) => {
    setPendingChanges(formData);
    setShowSaveConfirm(true);
  };

  const confirmSaveChanges = async () => {
    if (!editingUser || !pendingChanges) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update(pendingChanges)
        .eq('id', editingUser.id);

      if (error) throw error;
      toast.success('Bruger opdateret');
      fetchUsers();
      setShowEditModal(false);
      setShowSaveConfirm(false);
      setPendingChanges(null);
      setEditingUser(null);
    } catch (error) {
      console.error('Error updating user:', error);
      toast.error('Kunne ikke opdatere bruger');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Brugeradministration</h2>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bruger
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rolle
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Sidste login
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Handlinger
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {users.map((userProfile) => (
              <tr key={userProfile.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                      {userProfile.avatar_url ? (
                        <img
                          src={userProfile.avatar_url}
                          alt={`${userProfile.username}'s avatar`}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <User className="h-6 w-6 text-gray-500" />
                      )}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {userProfile.full_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {userProfile.email}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    userProfile.role === 'admin'
                      ? 'bg-red-100 text-red-800'
                      : userProfile.role === 'editor'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {userProfile.role === 'admin' ? 'Administrator' :
                     userProfile.role === 'editor' ? 'Redaktør' : 'Bruger'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {userProfile.status === 'active' ? (
                    <span className="text-green-600 flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" /> Aktiv
                    </span>
                  ) : (
                    <span className="text-red-600 flex items-center gap-1">
                      <XCircle className="w-4 h-4" /> Inaktiv
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {userProfile.last_login_at
                    ? format(new Date(userProfile.last_login_at), 'dd/MM/yyyy HH:mm', { locale: da })
                    : 'Aldrig'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => handleResetPassword(userProfile)}
                    className="text-blue-600 hover:text-blue-900 mr-4"
                    title="Nulstil adgangskode"
                  >
                    <Lock className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleEdit(userProfile)}
                    className="text-green-600 hover:text-green-900 mr-4"
                    title="Rediger bruger"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(userProfile)}
                    className="text-red-600 hover:text-red-900"
                    title="Slet bruger"
                    disabled={userProfile.role === 'admin' && users.filter(u => u.role === 'admin').length <= 1}
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && userToDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Bekræft sletning</h3>
            <p className="text-gray-600 mb-6">
              Er du sikker på, at du vil slette brugeren {userToDelete.username}? Denne handling kan ikke fortrydes.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setUserToDelete(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Annuller
              </button>
              <button
                onClick={confirmDelete}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                Ja, slet bruger
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Password Confirmation Modal */}
      {showResetConfirm && userToReset && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Bekræft nulstilling af adgangskode</h3>
            <p className="text-gray-600 mb-6">
              Er du sikker på, at du vil sende en email til {userToReset.email} med instruktioner til at nulstille adgangskoden?
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowResetConfirm(false);
                  setUserToReset(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Annuller
              </button>
              <button
                onClick={confirmResetPassword}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Ja, send email
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditModal && editingUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Rediger bruger</h3>
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              handleUpdateUser({
                full_name: formData.get('full_name') as string,
                role: formData.get('role') as string,
                status: formData.get('status') as string
              });
            }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Fulde navn
                  </label>
                  <input
                    type="text"
                    name="full_name"
                    defaultValue={editingUser.full_name || ''}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Rolle
                  </label>
                  <select
                    name="role"
                    defaultValue={editingUser.role}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  >
                    <option value="viewer">Bruger</option>
                    <option value="editor">Redaktør</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Status
                  </label>
                  <select
                    name="status"
                    defaultValue={editingUser.status}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  >
                    <option value="active">Aktiv</option>
                    <option value="inactive">Inaktiv</option>
                    <option value="suspended">Suspenderet</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingUser(null);
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Annuller
                </button>
                <button
                  type="submit"
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
                >
                  Gem ændringer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Save Changes Confirmation Modal */}
      {showSaveConfirm && editingUser && pendingChanges && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Bekræft ændringer</h3>
            <p className="text-gray-600 mb-6">
              Er du sikker på, at du vil gemme ændringerne for brugeren {editingUser.username}?
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowSaveConfirm(false);
                  setPendingChanges(null);
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Annuller
              </button>
              <button
                onClick={confirmSaveChanges}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                Ja, gem ændringer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}