import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ButtonProps {
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
  icon?: LucideIcon;
  onClick?: () => void;
  className?: string;
}

export function Button({ 
  variant = 'primary', 
  children, 
  icon: Icon, 
  onClick, 
  className = '' 
}: ButtonProps) {
  const baseStyles = "px-8 py-4 rounded-full text-lg font-medium transition-all duration-300 flex items-center gap-2";
  const variants = {
    primary: "bg-lap-navy hover:bg-lap-navy-light text-white shadow-lg hover:shadow-xl hover:-translate-y-1",
    secondary: "bg-lap-gold hover:bg-lap-gold-light text-lap-navy hover:-translate-y-1 shadow-lg hover:shadow-xl"
  };

  return (
    <button 
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {Icon && <Icon className="w-5 h-5" />}
      {children}
    </button>
  );
}