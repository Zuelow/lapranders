import React from 'react';
import { LucideIcon } from 'lucide-react';

interface InfoCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export function InfoCard({ icon: Icon, title, description }: InfoCardProps) {
  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-lap-navy/10">
      <div className="bg-lap-navy/10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 hover-rotate">
        <Icon className="w-8 h-8 text-lap-navy" />
      </div>
      <h3 className="text-xl font-semibold mb-4 text-lap-navy">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
  );
}