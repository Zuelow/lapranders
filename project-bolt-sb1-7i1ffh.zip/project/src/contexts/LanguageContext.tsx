import React, { createContext, useContext, useState } from 'react';

type Language = 'da' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  translations: typeof translations[Language];
}

const translations = {
  da: {
    title: 'LAP Aalborg',
    subtitle: 'Landsforeningen af nuværende og tidligere Psykiatribrugere',
    description: 'LAP - et fællesskab med hjertet på rette sted. Sammen skaber vi håb og forandring for mennesker berørt af psykiske udfordringer. Gennem varme fællesskaber, gensidig støtte og meningsfulde aktiviteter arbejder vi for en bedre hverdag og stærkere rettigheder for alle, der har eller har haft kontakt med psykiatrien.',
    joinButton: 'Bliv Medlem',
    nav: {
      vision: 'Vision',
      history: 'Historie',
      focus: 'Fokusområder',
      merchandise: 'Støt Os',
      join: 'Deltag'
    },
    vision: {
      title: 'Vores Vision',
      subtitle: 'Et stærkere fællesskab for psykiatribrugere',
      points: [
        'Styrke brugerindflydelse i psykiatrien',
        'Skabe meningsfulde fællesskaber',
        'Fremme recovery og personlig udvikling',
        'Kæmpe for bedre vilkår og rettigheder'
      ]
    },
    history: {
      title: 'Vores Historie',
      subtitle: 'En stærk stemme for psykiatribrugere',
      timeline: [
        'Grundlagt som en del af den nationale LAP-organisation',
        'Etablering af samarbejde med Psykiatriens Hus',
        'Udvikling af støttegrupper og aktiviteter',
        'Vækst til 50 engagerede medlemmer'
      ]
    },
    focus: {
      title: 'Fokusområder',
      subtitle: 'Sammen om en bedre psykiatri',
      areas: [
        {
          title: 'Brugerindflydelse',
          description: 'Vi arbejder for at styrke brugernes stemme i psykiatrien',
          points: [
            'Medbestemmelse i behandling',
            'Indflydelse på psykiatriens udvikling',
            'Støtte til selvbestemmelse',
            'Dialog med beslutningstagere'
          ]
        },
        {
          title: 'Fællesskab & Støtte',
          description: 'Vi skaber rum for fællesskab og gensidig støtte',
          points: [
            'Sociale aktiviteter og netværk',
            'Støttegrupper og erfaringsudveksling',
            'Peer-to-peer support',
            'Inkluderende miljøer'
          ]
        }
      ]
    },
    merchandise: {
      title: 'Støt Vores Arbejde',
      products: [
        {
          title: 'LAP T-shirt',
          description: 'Støt vores arbejde med en t-shirt',
          price: '200 kr'
        },
        {
          title: 'LAP Mulepose',
          description: 'Bæredygtig mulepose med logo',
          price: '150 kr'
        }
      ]
    },
    join: {
      title: 'Bliv Medlem',
      subtitle: 'Vær med i vores fællesskab',
      cta: 'Tilmeld dig nu'
    }
  },
  en: {
    title: 'LAP Aalborg',
    subtitle: 'National Association of Current and Former Psychiatry Users',
    description: 'LAP - a community with its heart in the right place. Together we create hope and change for people affected by mental health challenges. Through warm communities, mutual support, and meaningful activities, we work for a better everyday life and stronger rights for all who have or have had contact with psychiatry.',
    joinButton: 'Become a Member',
    nav: {
      vision: 'Vision',
      history: 'History',
      focus: 'Focus Areas',
      merchandise: 'Support Us',
      join: 'Join'
    },
    vision: {
      title: 'Our Vision',
      subtitle: 'A stronger community for psychiatry users',
      points: [
        'Strengthen user influence in psychiatry',
        'Create meaningful communities',
        'Promote recovery and personal development',
        'Fight for better conditions and rights'
      ]
    },
    history: {
      title: 'Our History',
      subtitle: 'A strong voice for psychiatry users',
      timeline: [
        'Founded as part of the national LAP organization',
        'Establishment of cooperation with Psychiatry House',
        'Development of support groups and activities',
        'Growth to 50 engaged members'
      ]
    },
    focus: {
      title: 'Focus Areas',
      subtitle: 'Together for better psychiatry',
      areas: [
        {
          title: 'User Influence',
          description: 'We work to strengthen users\' voice in psychiatry',
          points: [
            'Co-determination in treatment',
            'Influence on psychiatric development',
            'Support for self-determination',
            'Dialogue with decision makers'
          ]
        },
        {
          title: 'Community & Support',
          description: 'We create space for community and mutual support',
          points: [
            'Social activities and networking',
            'Support groups and experience sharing',
            'Peer-to-peer support',
            'Inclusive environments'
          ]
        }
      ]
    },
    merchandise: {
      title: 'Support Our Work',
      products: [
        {
          title: 'LAP T-shirt',
          description: 'Support our work with a t-shirt',
          price: '200 DKK'
        },
        {
          title: 'LAP Tote Bag',
          description: 'Sustainable tote bag with logo',
          price: '150 DKK'
        }
      ]
    },
    join: {
      title: 'Become a Member',
      subtitle: 'Join our community',
      cta: 'Sign up now'
    }
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('da');

  return (
    <LanguageContext.Provider value={{ language, setLanguage, translations: translations[language] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}