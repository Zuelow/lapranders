import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '../lib/types';
import { toast } from 'react-hot-toast';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

async function retryOperation<T>(
  operation: () => Promise<T>,
  retries: number = MAX_RETRIES,
  delay: number = RETRY_DELAY
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    if (retries > 0) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryOperation(operation, retries - 1, delay * 2);
    }
    throw error;
  }
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUser(session.user.id);
      } else {
        setLoading(false);
        setUser(null);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUser(session.user.id);
      } else {
        setUser(null);
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function fetchUser(userId: string) {
    try {
      const { data: profile, error } = await retryOperation(async () => {
        const result = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (result.error) {
          console.error('Supabase query error:', result.error);
          throw result.error;
        }

        return result;
      });

      if (error) throw error;

      setUser({
        id: userId,
        email: profile?.email || '',
        profile
      });
    } catch (error: any) {
      console.error('Error fetching user profile:', error);
      toast.error('Error loading user profile. Please try again.');
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  async function signIn(email: string, password: string) {
    try {
      const { data, error } = await retryOperation(async () => {
        const result = await supabase.auth.signInWithPassword({
          email,
          password
        });

        if (result.error) {
          console.error('Sign in error:', result.error);
          throw result.error;
        }

        return result;
      });

      if (error) {
        // Log failed login attempt
        await supabase.from('login_history').insert([{
          email,
          success: false,
          error_message: error.message
        }]);
        return { error };
      }

      // Log successful login
      if (data.user) {
        await supabase.from('login_history').insert([{
          email,
          success: true,
          user_id: data.user.id
        }]);

        // Update last login timestamp
        await supabase
          .from('profiles')
          .update({ last_login_at: new Date().toISOString() })
          .eq('id', data.user.id);
      }

      return { data };
    } catch (error) {
      console.error('Sign in error:', error);
      return { error };
    }
  }

  async function signOut() {
    try {
      const { error } = await retryOperation(async () => {
        const result = await supabase.auth.signOut();
        if (result.error) {
          console.error('Sign out error:', result.error);
          throw result.error;
        }
        return result;
      });

      if (error) throw error;
      toast.success('Logged out successfully');
      window.location.href = '/';
    } catch (error) {
      console.error('Sign out error:', error);
      toast.error('Error signing out');
    }
  }

  return {
    user,
    loading,
    signIn,
    signOut
  };
}