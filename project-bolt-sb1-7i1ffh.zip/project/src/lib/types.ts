import { Database } from './database.types';

export type Profile = Database['public']['Tables']['profiles']['Row'];
export type Content = Database['public']['Tables']['content']['Row'];
export type Category = Database['public']['Tables']['categories']['Row'];
export type ContentVersion = Database['public']['Tables']['content_versions']['Row'];

export type UserRole = 'admin' | 'editor' | 'viewer';
export type ContentStatus = 'draft' | 'published' | 'archived';

export interface User {
  id: string;
  email: string;
  profile: Profile | null;
}