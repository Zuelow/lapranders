import React from 'react';
import { Link } from 'react-router-dom';
import { Cookie, Shield, Lock, ArrowLeft } from 'lucide-react';

export function CookiesPolicy() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Tilbage til forsiden
        </Link>

        <div className="prose dark:prose-invert max-w-none">
          <div className="flex items-center gap-3 mb-6">
            <Cookie className="w-8 h-8 text-red-600" />
            <h1 className="text-3xl font-bold m-0">Cookiepolitik</h1>
          </div>

          <p className="lead text-xl text-gray-600 dark:text-gray-300">
            LAP Aalborg bruger cookies og lignende teknologier til at forbedre din brugeroplevelse og sikre hjemmesidens funktionalitet.
          </p>

          <h2 className="flex items-center gap-2 text-gray-900 dark:text-white">
            <Shield className="w-6 h-6 text-red-600" />
            Hvad er cookies?
          </h2>
          <p>
            Cookies er små tekstfiler, der gemmes på din computer eller mobile enhed, når du besøger vores hjemmeside. 
            De hjælper os med at huske dine præferencer og give dig en bedre brugeroplevelse.
          </p>

          <h2 className="flex items-center gap-2 text-gray-900 dark:text-white">
            Hvilke cookies bruger vi?
          </h2>
          <h3>Nødvendige cookies</h3>
          <p>
            Disse cookies er essentielle for hjemmesidens grundlæggende funktioner og kan ikke deaktiveres. De omfatter:
          </p>
          <ul>
            <li>Session cookies til at huske dine valg under dit besøg</li>
            <li>Sikkerhedscookies til at beskytte mod uautoriseret adgang</li>
            <li>Funktionelle cookies til at huske dine præferencer (f.eks. dark mode)</li>
          </ul>

          <h3>Statistik og analyse</h3>
          <p>
            Vi bruger anonymiserede data til at analysere brugen af vores hjemmeside og forbedre brugeroplevelsen:
          </p>
          <ul>
            <li>Besøgsstatistik</li>
            <li>Sidevisninger og navigation</li>
            <li>Teknisk information om din browser og enhed</li>
          </ul>

          <h2 className="flex items-center gap-2 text-gray-900 dark:text-white">
            <Lock className="w-6 h-6 text-red-600" />
            Sådan håndterer vi dine data
          </h2>
          <p>
            Vi behandler alle data i overensstemmelse med gældende databeskyttelseslovgivning, herunder GDPR. Vi:
          </p>
          <ul>
            <li>Indsamler kun nødvendige data</li>
            <li>Beskytter dine personoplysninger</li>
            <li>Deler ikke dine data med tredjeparter uden dit samtykke</li>
            <li>Opbevarer kun data i den nødvendige periode</li>
          </ul>

          <h2>Dine rettigheder</h2>
          <p>
            Du har ret til at:
          </p>
          <ul>
            <li>Få indsigt i de data, vi har om dig</li>
            <li>Få rettet eller slettet dine data</li>
            <li>Trække dit samtykke tilbage</li>
            <li>Klage til Datatilsynet</li>
          </ul>

          <h2>Kontakt os</h2>
          <p>
            Har du spørgsmål om vores brug af cookies eller behandling af dine data, er du velkommen til at kontakte os:
          </p>
          <ul>
            <li>Email: lap@lap.dk</li>
            <li>Telefon: 66 19 45 11</li>
            <li>Adresse: Store Glasvej 49, 5000 Odense C</li>
          </ul>

          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg mt-8">
            <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white">Opdatering af cookiepolitik</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-0">
              Vi forbeholder os retten til at opdatere denne cookiepolitik. Senest opdateret: April 2025
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}