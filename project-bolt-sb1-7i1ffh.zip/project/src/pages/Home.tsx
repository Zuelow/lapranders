import React, { useState } from 'react';
import { Heart, ChevronDown, Menu, X } from 'lucide-react';
import { About } from '../components/About';
import { Activities } from '../components/Activities';
import { Organization } from '../components/Organization';
import { FAQ } from '../components/FAQ';
import { Contact } from '../components/Contact';
import { HeaderCarousel } from '../components/HeaderCarousel';
import { Footer } from '../components/Footer';
import { CookieConsent } from '../components/CookieConsent';
import { News } from '../components/News';
import { ThemeToggle } from '../components/ThemeToggle';

export function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showMemberModal, setShowMemberModal] = useState(false);

  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    aboutSection?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const menuItems = [
    { id: 'news', href: '#news', text: 'Nyheder' },
    { id: 'about', href: '#about', text: 'Om LAP' },
    { id: 'organization', href: '#organization', text: 'Organisation' },
    { id: 'activities', href: '#activities', text: 'Aktiviteter' },
    { id: 'faq', href: '#faq', text: 'FAQ' },
    { id: 'contact', href: '#contact', text: 'Kontakt' }
  ];

  const handleMembershipClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setShowMemberModal(true);
  };

  return (
    <div className="min-h-screen">
      {/* Fixed Logo Container */}
      <div className="fixed top-0 left-0 z-50 p-4 pointer-events-none">
        <div className="flex flex-col items-center glass-effect p-2 rounded-lg bg-black/20 backdrop-blur-md pointer-events-auto">
          <div className="flex items-center gap-2">
            <img 
              src="https://www.lap.dk/wp-content/uploads/2020/12/lap-logo-1.svg" 
              alt="LAP Logo" 
              className="w-10 h-10 md:w-12 md:h-12 bg-white/90 p-1 rounded-lg"
            />
            <span className="text-lg md:text-2xl font-bold text-white">LAP Aalborg</span>
          </div>
          <a 
            href="https://www.lap.dk" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-sm mt-1 hover:underline transition text-center text-white"
          >
            En kommunal grundforening under www.lap.dk
          </a>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="relative">
        <HeaderCarousel />

        <header className="fixed top-0 right-0 z-50 p-4">
          <div className="flex items-center justify-end gap-4">
            <ThemeToggle />
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden glass-effect p-2 rounded-lg bg-black/20 backdrop-blur-md"
              aria-label={isMenuOpen ? 'Luk menu' : 'Åbn menu'}
            >
              {isMenuOpen ? (
                <X className="w-6 h-6 text-white" />
              ) : (
                <Menu className="w-6 h-6 text-white" />
              )}
            </button>

            <nav className="hidden md:flex space-x-8 glass-effect p-2 rounded-lg bg-black/20 backdrop-blur-md">
              {menuItems.map((item) => (
                <a 
                  key={item.id}
                  href={item.href} 
                  className="text-white hover:text-red-200 transition"
                >
                  {item.text}
                </a>
              ))}
            </nav>
          </div>

          {isMenuOpen && (
            <div className="md:hidden absolute top-full right-0 mt-2 bg-black/90 backdrop-blur-lg rounded-lg">
              <nav className="flex flex-col p-4">
                {menuItems.map((item) => (
                  <a
                    key={item.id}
                    href={item.href}
                    className="text-white hover:text-red-200 transition py-3 px-4 text-lg border-b border-white/10 last:border-none"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.text}
                  </a>
                ))}
              </nav>
            </div>
          )}
        </header>

        <div className="relative flex flex-col items-center justify-center min-h-screen px-4">
          <div className="text-center max-w-4xl mx-auto space-y-6 md:space-y-8 animate-fade-in">
            <img 
              src="https://www.lap.dk/wp-content/uploads/2020/12/lap-logo-1.svg" 
              alt="LAP Logo" 
              className="w-24 h-24 md:w-32 md:h-32 mx-auto mb-6 md:mb-8 bg-white/90 p-4 rounded-lg animate-scale-in"
            />
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4 md:mb-6 animate-scale-in leading-tight">
              LAP Aalborg - Landsforeningen Af nuværende og tidligere Psykiatri brugere
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl text-white/90 mb-8 md:mb-12 leading-relaxed animate-slide-in">
              Intet om os uden os... LAP Aalborg er en forening, hvor nuværende og tidligere Psykiatri brugere kan støtte hinanden, tage fælles initiativer, formulere en politik og stille krav til vedrørende vore egne interesser.
            </p>
            <a 
              href="https://www.lap.dk/bliv-medlem/"
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleMembershipClick}
              className="inline-block bg-white text-red-600 px-6 md:px-8 py-3 md:py-4 rounded-full font-bold text-base md:text-lg hover:bg-red-100 transition-all flex items-center gap-2 mx-auto hover:-translate-y-1 shadow-lg"
            >
              <Heart className="w-5 h-5" />
              <span>Bliv Medlem</span>
            </a>
          </div>
          
          <button 
            onClick={scrollToAbout}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce cursor-pointer"
            aria-label="Scroll til om os sektion"
          >
            <ChevronDown className="w-8 h-8 text-white/80" />
          </button>
        </div>
      </div>

      {showMemberModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50" onClick={() => setShowMemberModal(false)}>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md mx-4 shadow-xl" onClick={e => e.stopPropagation()}>
            <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Bliv medlem af LAP</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Du vil nu blive sendt videre til LAP's nationale hjemmeside, hvor du kan melde dig ind i foreningen.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowMemberModal(false)}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 transition-colors"
              >
                Annuller
              </button>
              <a
                href="https://www.lap.dk/bliv-medlem/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors"
                onClick={() => setShowMemberModal(false)}
              >
                Fortsæt til indmeldelse
              </a>
            </div>
          </div>
        </div>
      )}

      <News />
      <About />
      <Organization />
      <Activities />
      <FAQ />
      <Contact />
      <Footer />
      <CookieConsent />
    </div>
  );
}