/*
  # Create news and users tables

  1. New Tables
    - `news_articles`
      - `id` (uuid, primary key)
      - `title` (text)
      - `content` (text)
      - `date` (timestamptz)
      - `images` (jsonb)
      - `author_id` (uuid, references auth.users)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `news_articles` table
    - Add policies for authenticated users to manage their articles
    - Add policy for public read access
*/

CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  date timestamptz NOT NULL DEFAULT now(),
  images jsonb DEFAULT '[]'::jsonb,
  author_id uuid REFERENCES auth.users NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to create articles
CREATE POLICY "Users can create articles"
  ON news_articles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

-- Allow users to update their own articles
CREATE POLICY "Users can update own articles"
  ON news_articles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- Allow users to delete their own articles
CREATE POLICY "Users can delete own articles"
  ON news_articles
  FOR DELETE
  TO authenticated
  USING (auth.uid() = author_id);

-- Allow public read access to all articles
CREATE POLICY "Public can view articles"
  ON news_articles
  FOR SELECT
  TO public
  USING (true);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_news_articles_updated_at
  BEFORE UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();