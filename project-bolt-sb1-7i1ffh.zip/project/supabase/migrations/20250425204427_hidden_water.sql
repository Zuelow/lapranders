/*
  # Create admin user and profile

  1. Changes
    - Create admin user with email admin@lap-aalborg.dk
    - Create corresponding profile with admin role
    - Handle potential conflicts properly
*/

-- Create the admin user
WITH new_user AS (
  SELECT id, email 
  FROM auth.users 
  WHERE email = 'admin@lap-aalborg.dk'
)
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
)
SELECT 
  gen_random_uuid(),
  'admin@lap-aalborg.dk',
  crypt('Admin123!', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  now(),
  now(),
  '',
  '',
  '',
  ''
WHERE NOT EXISTS (SELECT 1 FROM new_user)
RETURNING id;

-- Create the admin profile
WITH admin_user AS (
  SELECT id FROM auth.users WHERE email = 'admin@lap-aalborg.dk'
)
INSERT INTO public.profiles (
  id,
  username,
  full_name,
  role
)
SELECT 
  id,
  'admin',
  'LAP Admin',
  'admin'
FROM admin_user
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles p
  INNER JOIN admin_user au ON p.id = au.id
);