/*
  # Admin User and Security Setup

  1. Security Updates
    - Add login attempt tracking
    - Add session management
    - Add audit logging

  2. Admin User Setup
    - Create admin user with secure password
    - Set up admin profile with full permissions
*/

-- Create audit log table
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users,
  action text NOT NULL,
  details jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY "Only admins can view audit logs"
  ON audit_logs FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Create login attempts tracking
CREATE TABLE IF NOT EXISTS login_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  ip_address text,
  success boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE login_attempts ENABLE ROW LEVEL SECURITY;

-- Only admins can view login attempts
CREATE POLICY "Only admins can view login attempts"
  ON login_attempts FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Create the admin user if it doesn't exist
WITH new_user AS (
  SELECT id, email 
  FROM auth.users 
  WHERE email = 'admin@lap-aalborg.dk'
)
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
)
SELECT 
  gen_random_uuid(),
  'admin@lap-aalborg.dk',
  crypt('Admin123!', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{"role":"admin"}',
  now(),
  now(),
  '',
  '',
  '',
  ''
WHERE NOT EXISTS (SELECT 1 FROM new_user)
RETURNING id;

-- Create the admin profile
WITH admin_user AS (
  SELECT id FROM auth.users WHERE email = 'admin@lap-aalborg.dk'
)
INSERT INTO public.profiles (
  id,
  username,
  full_name,
  role
)
SELECT 
  id,
  'admin',
  'LAP Admin',
  'admin'
FROM admin_user
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles p
  INNER JOIN admin_user au ON p.id = au.id
);

-- Create function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO audit_logs (user_id, action, details)
  VALUES (auth.uid(), TG_ARGV[0], row_to_json(NEW));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for audit logging
CREATE TRIGGER log_content_changes
  AFTER INSERT OR UPDATE OR DELETE ON content
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_action('content_change');

CREATE TRIGGER log_category_changes
  AFTER INSERT OR UPDATE OR DELETE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_action('category_change');