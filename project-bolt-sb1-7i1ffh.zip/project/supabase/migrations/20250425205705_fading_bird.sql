/*
  # Fix Admin User Authentication

  1. Updates
    - Create admin user with proper auth configuration
    - Ensure password is correctly hashed
    - Set up proper user metadata
    - Create corresponding profile

  Note: This migration supersedes previous admin user creation attempts
*/

-- First, ensure we have the crypto extension
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create admin user with proper auth configuration
DO $$
DECLARE
    new_user_id uuid;
BEGIN
    -- Insert into auth.users
    INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        recovery_sent_at,
        last_sign_in_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        email_change,
        email_change_token_new,
        recovery_token
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        'admin@lap-aalborg.dk',
        crypt('Admin123!', gen_salt('bf')),
        NOW(),
        NOW(),
        NOW(),
        jsonb_build_object('provider', 'email', 'providers', ARRAY['email']),
        jsonb_build_object('role', 'admin'),
        NOW(),
        NOW(),
        '',
        '',
        '',
        ''
    )
    RETURNING id INTO new_user_id;

    -- Create profile if user was created
    IF new_user_id IS NOT NULL THEN
        INSERT INTO public.profiles (
            id,
            username,
            full_name,
            role,
            created_at,
            updated_at
        ) VALUES (
            new_user_id,
            'admin',
            'LAP Admin',
            'admin',
            NOW(),
            NOW()
        );
    END IF;
EXCEPTION
    WHEN unique_violation THEN
        -- If the user already exists, get their ID
        SELECT id INTO new_user_id FROM auth.users WHERE email = 'admin@lap-aalborg.dk';
        
        -- Update their profile if needed
        INSERT INTO public.profiles (
            id,
            username,
            full_name,
            role,
            created_at,
            updated_at
        ) VALUES (
            new_user_id,
            'admin',
            'LAP Admin',
            'admin',
            NOW(),
            NOW()
        )
        ON CONFLICT (id) DO UPDATE SET
            role = 'admin',
            updated_at = NOW();
END
$$;