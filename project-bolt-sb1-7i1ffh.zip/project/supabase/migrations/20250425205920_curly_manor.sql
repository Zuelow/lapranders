/*
  # Fix Admin User Creation

  This migration fixes the admin user creation by:
  1. Properly handling foreign key constraints when removing existing user
  2. Using the correct password hashing method
  3. Setting proper metadata and role
  4. Ensuring proper profile creation
*/

DO $$
DECLARE
    new_user_id uuid;
BEGIN
    -- Delete existing admin user and profile in correct order to handle foreign key constraints
    DELETE FROM public.profiles WHERE username = 'admin';
    DELETE FROM auth.users WHERE email = 'admin@lap-aalborg.dk';

    -- Insert into auth.users with proper password hashing
    INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        'admin@lap-aalborg.dk',
        -- Use proper Supabase password hashing
        crypt('Admin123!', gen_salt('bf', 10)),
        now(),
        '{"provider": "email", "providers": ["email"]}',
        '{"role": "admin"}',
        now(),
        now(),
        '',
        ''
    )
    RETURNING id INTO new_user_id;

    -- Create admin profile
    INSERT INTO public.profiles (
        id,
        username,
        full_name,
        role,
        created_at,
        updated_at
    ) VALUES (
        new_user_id,
        'admin',
        'LAP Admin',
        'admin',
        now(),
        now()
    );
END
$$;