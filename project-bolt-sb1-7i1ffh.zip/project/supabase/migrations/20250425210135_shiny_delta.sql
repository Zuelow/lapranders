/*
  # Create admin user with proper authentication setup

  1. Changes
    - Creates admin user with email 'admin@lap-aalborg.dk' and password 'Admin123!'
    - Sets up proper profile with admin role
    - Handles existing user cleanup safely

  2. Security
    - Uses proper password hashing
    - Sets up necessary metadata
    - Ensures clean state for admin user
*/

-- First, clean up any existing admin user data
DO $$
BEGIN
    -- Delete profile first to handle foreign key constraint
    DELETE FROM public.profiles WHERE username = 'admin';
    -- Then delete the user
    DELETE FROM auth.users WHERE email = 'admin@lap-aalborg.dk';
END $$;

-- Create the admin user
INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token,
    email_change,
    email_change_token_new,
    invited_at
) VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@lap-aalborg.dk',
    crypt('Admin123!', gen_salt('bf')),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    '{"role": "admin"}',
    now(),
    now(),
    '',
    '',
    '',
    '',
    now()
);

-- Create the admin profile
INSERT INTO public.profiles (
    id,
    username,
    full_name,
    role,
    created_at,
    updated_at
)
SELECT
    id,
    'admin',
    'LAP Admin',
    'admin',
    now(),
    now()
FROM auth.users
WHERE email = 'admin@lap-aalborg.dk';