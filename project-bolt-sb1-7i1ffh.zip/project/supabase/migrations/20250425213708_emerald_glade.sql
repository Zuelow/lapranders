/*
  # Update news system and categories

  1. Changes
    - Drop existing policies to avoid conflicts
    - Recreate news_articles table with proper structure
    - Add new policies for article management
    - Insert default categories

  2. Security
    - Enable RLS
    - Add policies for editors and admins
    - Allow public read access
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can update own articles" ON news_articles;
  DROP POLICY IF EXISTS "Editors and admins can create articles" ON news_articles;
  DROP POLICY IF EXISTS "Only admins can delete articles" ON news_articles;
  DROP POLICY IF EXISTS "Public can view articles" ON news_articles;
EXCEPTION
  WHEN undefined_table THEN
    NULL;
END $$;

-- Recreate the table if it doesn't exist
CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  date timestamptz NOT NULL DEFAULT now(),
  images jsonb DEFAULT '[]'::jsonb,
  author_id uuid REFERENCES auth.users NOT NULL,
  category_id uuid REFERENCES categories,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Editors and admins can create articles"
  ON news_articles FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "Users can update own articles"
  ON news_articles FOR UPDATE
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Only admins can delete articles"
  ON news_articles FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Public can view articles"
  ON news_articles FOR SELECT
  USING (true);

-- Create updated_at trigger if it doesn't exist
DO $$ 
BEGIN
  CREATE TRIGGER update_news_articles_updated_at
    BEFORE UPDATE ON news_articles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

-- Insert default categories
INSERT INTO categories (name, slug) VALUES
  ('Nyheder', 'nyheder'),
  ('Arrangementer', 'arrangementer'),
  ('Pressemeddelelser', 'pressemeddelelser')
ON CONFLICT (slug) DO NOTHING;