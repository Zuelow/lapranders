-- Drop existing table and policies
DROP TABLE IF EXISTS news_articles CASCADE;

-- Recreate news_articles table with correct relationships
CREATE TABLE news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  date timestamptz NOT NULL DEFAULT now(),
  images jsonb DEFAULT '[]'::jsonb,
  author_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('draft', 'published', 'archived'))
);

-- Enable RLS
ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public can view published articles"
  ON news_articles FOR SELECT
  USING (status = 'published' OR auth.uid() = author_id);

CREATE POLICY "Editors and admins can create articles"
  ON news_articles FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'editor')
    )
  );

CREATE POLICY "Authors can update own articles"
  ON news_articles FOR UPDATE
  USING (auth.uid() = author_id OR EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ))
  WITH CHECK (auth.uid() = author_id OR EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Only admins can delete articles"
  ON news_articles FOR DELETE
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Create updated_at trigger
CREATE TRIGGER update_news_articles_updated_at
  BEFORE UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Create audit trigger
CREATE TRIGGER audit_news_articles
  AFTER INSERT OR DELETE OR UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION audit_log_change();