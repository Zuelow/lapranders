/*
  # Add foreign key relationship for news articles

  1. Changes
    - Add foreign key constraint from news_articles.author_id to profiles.id
    - Add index on author_id column for better query performance
    
  2. Security
    - No changes to RLS policies
*/

-- Add foreign key constraint
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'news_articles_author_id_fkey'
  ) THEN
    ALTER TABLE news_articles
    ADD CONSTRAINT news_articles_author_id_fkey
    FOREIGN KEY (author_id) REFERENCES profiles(id)
    ON DELETE CASCADE;
  END IF;
END $$;

-- Add index on author_id for better join performance
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_indexes 
    WHERE indexname = 'news_articles_author_id_idx'
  ) THEN
    CREATE INDEX news_articles_author_id_idx ON news_articles(author_id);
  END IF;
END $$;