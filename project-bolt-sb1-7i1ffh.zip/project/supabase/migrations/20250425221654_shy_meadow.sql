/*
  # Add initial data
  
  1. New Data
    - Add initial admin user
    - Add sample news article
    
  2. Changes
    - Insert into auth.users table
    - Insert into profiles table
    - Insert into news_articles table with correct foreign key reference
*/

-- Create UUID extension if not exists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Insert admin user if not exists
DO $$
DECLARE
    admin_id uuid;
BEGIN
    -- Generate a new UUID for the admin user
    admin_id := uuid_generate_v4();
    
    -- Insert into auth.users
    INSERT INTO auth.users (id, email, created_at)
    SELECT 
        admin_id,
        'admin@lap-aalborg.dk',
        NOW()
    WHERE NOT EXISTS (
        SELECT 1 FROM auth.users WHERE email = 'admin@lap-aalborg.dk'
    );

    -- Get the user ID (either newly inserted or existing)
    SELECT id INTO admin_id
    FROM auth.users
    WHERE email = 'admin@lap-aalborg.dk'
    LIMIT 1;

    -- Insert admin profile
    INSERT INTO public.profiles (
        id,
        email,
        username,
        full_name,
        role,
        created_at,
        updated_at
    )
    SELECT
        admin_id,
        'admin@lap-aalborg.dk',
        'Admin',
        'LAP Administrator',
        'admin',
        NOW(),
        NOW()
    WHERE NOT EXISTS (
        SELECT 1 FROM public.profiles WHERE email = 'admin@lap-aalborg.dk'
    );

    -- Insert sample news article
    INSERT INTO public.news_articles (
        title,
        content,
        date,
        status,
        author_id,
        created_at,
        updated_at
    )
    SELECT
        'Velkommen til LAP Aalborg',
        E'Vi er glade for at kunne byde velkommen til LAP Aalborgs nye hjemmeside!\n\nHer vil du kunne finde information om vores aktiviteter, nyheder og meget mere. Vi arbejder konstant på at forbedre vores tilbud og services til vores medlemmer.\n\nHold øje med siden for kommende arrangementer og nyheder.',
        NOW(),
        'published',
        admin_id,
        NOW(),
        NOW()
    WHERE NOT EXISTS (
        SELECT 1 FROM public.news_articles
        LIMIT 1
    );
END $$;