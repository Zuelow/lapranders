/*
  # Add foreign key relationship between news_articles and profiles

  1. Changes
    - Add foreign key constraint from news_articles.author_id to profiles.id
    - Add index on author_id for better query performance

  2. Security
    - No changes to RLS policies
*/

-- Add foreign key constraint
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'news_articles_author_id_profiles_fkey'
  ) THEN
    ALTER TABLE news_articles
    ADD CONSTRAINT news_articles_author_id_profiles_fkey
    FOREIGN KEY (author_id) REFERENCES profiles(id)
    ON DELETE CASCADE;
  END IF;
END $$;

-- Add index for better join performance
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE indexname = 'news_articles_author_id_profiles_idx'
  ) THEN
    CREATE INDEX news_articles_author_id_profiles_idx ON news_articles(author_id);
  END IF;
END $$;