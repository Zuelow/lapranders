/*
  # User Management System Schema

  1. New Tables
    - user_roles: Stores role definitions and permissions
    - user_sessions: Tracks user login sessions
    - login_history: Tracks login attempts and security events

  2. Updates
    - Adds new columns to profiles table
    - Adds security-related constraints and triggers

  3. Security
    - Implements RLS policies for secure access
    - Adds audit logging for administrative actions
*/

-- Create user_roles table
CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  permissions jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_sessions table
CREATE TABLE IF NOT EXISTS public.user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  ip_address text,
  user_agent text,
  last_active timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  remember_me boolean DEFAULT false
);

-- Create login_history table
CREATE TABLE IF NOT EXISTS public.login_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  email text NOT NULL,
  success boolean DEFAULT false,
  ip_address text,
  user_agent text,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Add new columns to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS phone text,
ADD COLUMN IF NOT EXISTS status text DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
ADD COLUMN IF NOT EXISTS failed_login_attempts integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_login_at timestamptz,
ADD COLUMN IF NOT EXISTS password_changed_at timestamptz,
ADD COLUMN IF NOT EXISTS requires_password_change boolean DEFAULT false;

-- Create default roles
INSERT INTO public.user_roles (name, description, permissions) VALUES
('admin', 'Full system access', '["all"]'::jsonb),
('manager', 'Manage users and content', '["manage_users", "manage_content"]'::jsonb),
('editor', 'Edit and publish content', '["edit_content", "publish_content"]'::jsonb),
('user', 'Basic user access', '["view_content"]'::jsonb)
ON CONFLICT (name) DO NOTHING;

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.login_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage roles"
ON public.user_roles
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Users can view their own sessions"
ON public.user_sessions
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Admins can view all sessions"
ON public.user_sessions
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

CREATE POLICY "Admins can view login history"
ON public.login_history
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

-- Create function to log login attempts
CREATE OR REPLACE FUNCTION public.log_login_attempt(
  p_email text,
  p_success boolean,
  p_ip_address text,
  p_user_agent text,
  p_error_message text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.login_history (
    user_id,
    email,
    success,
    ip_address,
    user_agent,
    error_message
  )
  SELECT
    id,
    p_email,
    p_success,
    p_ip_address,
    p_user_agent,
    p_error_message
  FROM auth.users
  WHERE email = p_email;

  -- Update failed login attempts if failure
  IF NOT p_success THEN
    UPDATE public.profiles
    SET failed_login_attempts = COALESCE(failed_login_attempts, 0) + 1
    WHERE email = p_email;
  ELSE
    -- Reset failed attempts and update last login on success
    UPDATE public.profiles
    SET
      failed_login_attempts = 0,
      last_login_at = now()
    WHERE email = p_email;
  END IF;
END;
$$;

-- Create function to check if user account is locked
CREATE OR REPLACE FUNCTION public.is_account_locked(p_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_failed_attempts integer;
  v_status text;
BEGIN
  SELECT failed_login_attempts, status
  INTO v_failed_attempts, v_status
  FROM public.profiles
  WHERE id = p_user_id;

  RETURN v_failed_attempts >= 5 OR v_status = 'suspended';
END;
$$;

-- Create updated_at trigger for user_roles
CREATE TRIGGER update_user_roles_updated_at
  BEFORE UPDATE ON public.user_roles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON public.user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_login_history_user_id ON public.login_history(user_id);
CREATE INDEX IF NOT EXISTS idx_login_history_created_at ON public.login_history(created_at);