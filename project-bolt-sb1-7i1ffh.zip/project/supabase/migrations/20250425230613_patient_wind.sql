/*
  # Fix RLS recursion in profiles policies

  1. Changes
    - Drop existing policies that cause recursion
    - Create new policies with non-recursive admin checks
    - Simplify policy logic to prevent circular dependencies

  2. Security
    - Maintain same security level but with better implementation
    - Ensure admins retain full access
    - Protect user data appropriately
*/

-- Drop existing policies to start fresh
DROP POLICY IF EXISTS "Admins can do everything" ON profiles;
DROP POLICY IF EXISTS "Users can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Allow profile creation during signup" ON profiles;

-- Create new non-recursive policies
CREATE POLICY "Allow admin full access"
ON profiles
FOR ALL
TO authenticated
USING (
  (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
);

CREATE POLICY "Allow users to view profiles"
ON profiles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow users to update own profile"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id AND (
    CASE
      WHEN (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin' THEN true
      ELSE role = 'viewer'
    END
  )
);

CREATE POLICY "Allow profile creation"
ON profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);