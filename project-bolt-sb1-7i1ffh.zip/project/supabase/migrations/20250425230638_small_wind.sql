/*
  # Fix recursive profiles policies

  1. Changes
    - Remove recursive admin check from profiles policies
    - Restructure policies to avoid infinite recursion
    - Maintain same security level while improving performance

  2. Security
    - Maintains row-level security
    - Preserves existing access control patterns
    - Eliminates recursive policy checks
*/

-- First, drop existing policies
DROP POLICY IF EXISTS "Allow admin full access" ON profiles;
DROP POLICY IF EXISTS "Allow profile creation" ON profiles;
DROP POLICY IF EXISTS "Allow users to update own profile" ON profiles;
DROP POLICY IF EXISTS "Allow users to view profiles" ON profiles;

-- Create new, non-recursive policies
CREATE POLICY "Allow users to view profiles"
ON profiles FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow users to create own profile"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "Allow users to update own profile"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  (auth.uid() = id) AND (
    CASE
      WHEN role = 'admin' THEN 
        EXISTS (SELECT 1 FROM auth.users WHERE auth.users.id = auth.uid())
      ELSE 
        role = 'viewer'
    END
  )
);

CREATE POLICY "Allow admins full access"
ON profiles FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM auth.users 
    WHERE auth.users.id = auth.uid() 
    AND id IN (
      SELECT p.id 
      FROM profiles p 
      WHERE p.role = 'admin'
    )
  )
);