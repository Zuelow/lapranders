/*
  # Fix profile policies to prevent recursion
  
  1. Changes
    - Drop existing policies
    - Create simplified policies without recursion
    - Maintain security while improving performance
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Allow admins full access" ON profiles;
DROP POLICY IF EXISTS "Allow users to create own profile" ON profiles;
DROP POLICY IF EXISTS "Allow users to view profiles" ON profiles;

-- Create new non-recursive policies
CREATE POLICY "View profiles"
ON profiles FOR SELECT
TO public
USING (true);

CREATE POLICY "Create own profile"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "Update own profile"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id AND
  CASE 
    WHEN role = 'admin' THEN EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
    ELSE role IN ('viewer', 'editor')
  END
);

CREATE POLICY "Admin full access"
ON profiles FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() 
    AND role = 'admin'
  )
);