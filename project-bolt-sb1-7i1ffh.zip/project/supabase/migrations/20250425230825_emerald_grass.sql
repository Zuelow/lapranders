/*
  # Fix RLS recursion error

  1. Changes
    - Drop existing recursive policies
    - Create simplified non-recursive policies
    - Fix profile and news article relationships

  2. Security
    - Maintain security while avoiding recursion
    - Keep proper access controls
*/

-- Drop existing policies
DROP POLICY IF EXISTS "View profiles" ON profiles;
DROP POLICY IF EXISTS "Create own profile" ON profiles;
DROP POLICY IF EXISTS "Update own profile" ON profiles;
DROP POLICY IF EXISTS "Admin full access" ON profiles;

-- Create simplified non-recursive policies
CREATE POLICY "Enable read access for all users"
ON profiles FOR SELECT
TO public
USING (true);

CREATE POLICY "Enable insert for authenticated users only"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "Enable update for users based on role"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id);

-- Update news_articles policies
DROP POLICY IF EXISTS "Public can view published articles" ON news_articles;
DROP POLICY IF EXISTS "Authors can update own articles" ON news_articles;

CREATE POLICY "Allow public to view published articles"
ON news_articles FOR SELECT
TO public
USING (status = 'published');

CREATE POLICY "Allow authors to view own articles"
ON news_articles FOR SELECT
TO authenticated
USING (auth.uid() = author_id);

CREATE POLICY "Allow authors to update own articles"
ON news_articles FOR UPDATE
TO authenticated
USING (auth.uid() = author_id);