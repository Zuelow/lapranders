/*
  # Fix profile policies and add performance optimizations

  1. Changes
    - Drop and recreate policies to avoid conflicts
    - Add performance optimization with role index
    - Ensure proper access control for all operations

  2. Security
    - Public read access for profiles
    - Authenticated users can manage own profiles
    - Admins have full access
*/

DO $$ 
BEGIN
    -- Drop all existing policies for profiles
    DROP POLICY IF EXISTS "Enable read access for all users" ON profiles;
    DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON profiles;
    DROP POLICY IF EXISTS "Enable update for users based on role" ON profiles;
    DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
    DROP POLICY IF EXISTS "Allow public read access" ON profiles;
    DROP POLICY IF EXISTS "Allow authenticated users to create profile" ON profiles;
    DROP POLICY IF EXISTS "Allow users to update own profile" ON profiles;
    DROP POLICY IF EXISTS "Allow admins full access" ON profiles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create new policies with unique names
CREATE POLICY "profiles_public_read_20250425"
ON profiles FOR SELECT
TO public
USING (true);

CREATE POLICY "profiles_auth_insert_20250425"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_auth_update_20250425"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_admin_all_20250425"
ON profiles FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  )
);

-- Drop index if exists to avoid conflicts
DROP INDEX IF EXISTS idx_profiles_role;

-- Create index for better performance
CREATE INDEX idx_profiles_role ON profiles(role);