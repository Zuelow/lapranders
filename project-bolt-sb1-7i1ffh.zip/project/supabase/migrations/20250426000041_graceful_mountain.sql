/*
  # Fix infinite recursion in profile policies
  
  1. Changes
    - Remove recursive policy checks
    - Simplify admin role check
    - Fix news article queries
*/

-- Drop existing problematic policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "profiles_admin_all_20250425" ON profiles;
    DROP POLICY IF EXISTS "profiles_public_read_20250425" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_insert_20250425" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_update_20250425" ON profiles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create new non-recursive policies
CREATE POLICY "profiles_public_read_20250426"
ON profiles FOR SELECT
USING (true);

CREATE POLICY "profiles_auth_insert_20250426"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_auth_update_20250426"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create admin policy without recursion
CREATE POLICY "profiles_admin_all_20250426"
ON profiles FOR ALL
TO authenticated
USING (
  role = 'admin' AND auth.uid() = id
);

-- Update news articles policy to avoid profile recursion
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Public can view published articles" ON news_articles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

CREATE POLICY "Public can view published articles"
ON news_articles FOR SELECT
USING (status = 'published');