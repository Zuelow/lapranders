/*
  # Fix RLS policies to avoid recursion

  1. Changes
    - Drop existing problematic policies
    - Create new non-recursive policies for profiles table
    - Update news_articles policies to avoid recursion
    - Add proper indexes for performance

  2. Security
    - Maintain proper access control
    - Avoid circular references in policy checks
*/

-- Drop existing problematic policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "profiles_admin_all_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_public_read_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_insert_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_update_20250426" ON profiles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create new non-recursive policies for profiles
CREATE POLICY "profiles_admin_all_20250426"
ON profiles FOR ALL
TO authenticated
USING ((role = 'admin') AND (auth.uid() = id));

CREATE POLICY "profiles_auth_insert_20250426"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_auth_update_20250426"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_public_read_20250426"
ON profiles FOR SELECT
TO public
USING (true);

-- Update news_articles policies to avoid recursion
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Public can view published articles" ON news_articles;
    DROP POLICY IF EXISTS "Allow authors to view own articles" ON news_articles;
    DROP POLICY IF EXISTS "Allow authors to update own articles" ON news_articles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

CREATE POLICY "news_articles_public_read_20250426"
ON news_articles FOR SELECT
TO public
USING (status = 'published');

CREATE POLICY "news_articles_auth_read_20250426"
ON news_articles FOR SELECT
TO authenticated
USING (auth.uid() = author_id);

CREATE POLICY "news_articles_auth_update_20250426"
ON news_articles FOR UPDATE
TO authenticated
USING (auth.uid() = author_id)
WITH CHECK (auth.uid() = author_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_news_articles_status ON news_articles(status);
CREATE INDEX IF NOT EXISTS idx_news_articles_author_id ON news_articles(author_id);