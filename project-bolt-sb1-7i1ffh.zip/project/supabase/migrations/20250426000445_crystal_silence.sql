/*
  # Fix profile policies to avoid recursion

  1. Changes
    - Drop existing policies
    - Create new non-recursive policies for profiles
    - Add proper indexes for performance
*/

-- Drop existing policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "profiles_admin_all_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_public_read_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_insert_20250426" ON profiles;
    DROP POLICY IF EXISTS "profiles_auth_update_20250426" ON profiles;
EXCEPTION
    WHEN undefined_object THEN null;
END $$;

-- Create new non-recursive policies
CREATE POLICY "profiles_public_read_20250426"
ON profiles FOR SELECT
TO public
USING (true);

CREATE POLICY "profiles_auth_insert_20250426"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "profiles_auth_update_20250426"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create admin policy without recursion
CREATE POLICY "profiles_admin_all_20250426"
ON profiles FOR ALL
TO authenticated
USING ((role = 'admin') AND (auth.uid() = id));

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_role_20250426 ON profiles(role);