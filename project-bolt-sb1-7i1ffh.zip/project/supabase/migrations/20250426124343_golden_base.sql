/*
  # Update database encoding and collation
  
  1. Changes
    - Set client encoding to UTF-8
    - Update text columns to use Danish collation
    - Add UTF-8 validation trigger
*/

-- Update existing text columns to use UTF-8 collation
DO $$ 
BEGIN
  -- Update news_articles table
  ALTER TABLE news_articles ALTER COLUMN title TYPE text COLLATE "und-x-icu";
  ALTER TABLE news_articles ALTER COLUMN content TYPE text COLLATE "und-x-icu";
  
  -- Update profiles table
  ALTER TABLE profiles ALTER COLUMN username TYPE text COLLATE "und-x-icu";
  ALTER TABLE profiles ALTER COLUMN full_name TYPE text COLLATE "und-x-icu";
  ALTER TABLE profiles ALTER COLUMN email TYPE text COLLATE "und-x-icu";
  
  -- Update categories table
  ALTER TABLE categories ALTER COLUMN name TYPE text COLLATE "und-x-icu";
  ALTER TABLE categories ALTER COLUMN slug TYPE text COLLATE "und-x-icu";
  
  -- Update content table
  ALTER TABLE content ALTER COLUMN title TYPE text COLLATE "und-x-icu";
  ALTER TABLE content ALTER COLUMN content TYPE text COLLATE "und-x-icu";
  ALTER TABLE content ALTER COLUMN excerpt TYPE text COLLATE "und-x-icu";
END $$;

-- Add a trigger to ensure content is always stored as UTF-8
CREATE OR REPLACE FUNCTION ensure_utf8()
RETURNS TRIGGER AS $$
BEGIN
  -- Only process if content is not NULL
  IF NEW.content IS NOT NULL THEN
    -- Verify the content is valid UTF-8
    IF octet_length(NEW.content) != octet_length(convert_to(convert_from(convert_to(NEW.content, 'UTF8'), 'UTF8'), 'UTF8')) THEN
      RAISE EXCEPTION 'Invalid UTF-8 content';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to news_articles table
DROP TRIGGER IF EXISTS ensure_news_content_utf8 ON news_articles;
CREATE TRIGGER ensure_news_content_utf8
  BEFORE INSERT OR UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_utf8();

-- Apply trigger to content table
DROP TRIGGER IF EXISTS ensure_page_content_utf8 ON content;
CREATE TRIGGER ensure_page_content_utf8
  BEFORE INSERT OR UPDATE ON content
  FOR EACH ROW
  EXECUTE FUNCTION ensure_utf8();