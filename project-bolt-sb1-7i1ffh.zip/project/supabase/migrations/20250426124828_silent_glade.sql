/*
  # Fix character encoding for news articles
  
  1. Changes
    - Update text columns to use proper UTF-8 encoding
    - Add function to ensure UTF-8 content
    - Add trigger to validate content on insert/update
    - Fix existing content encoding issues
*/

-- Update text columns to use proper collation
ALTER TABLE news_articles ALTER COLUMN title TYPE text;
ALTER TABLE news_articles ALTER COLUMN content TYPE text;

-- Create function to ensure UTF-8 content
CREATE OR REPLACE FUNCTION ensure_utf8()
RETURNS TRIGGER AS $$
BEGIN
  -- Convert content to and from UTF-8 to ensure valid encoding
  IF NEW.content IS NOT NULL THEN
    NEW.content := convert_from(convert_to(NEW.content::text, 'UTF8'), 'UTF8');
  END IF;
  IF NEW.title IS NOT NULL THEN
    NEW.title := convert_from(convert_to(NEW.title::text, 'UTF8'), 'UTF8');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to ensure UTF-8 content
DROP TRIGGER IF EXISTS ensure_news_content_utf8 ON news_articles;
CREATE TRIGGER ensure_news_content_utf8
  BEFORE INSERT OR UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_utf8();

-- Fix existing content
UPDATE news_articles 
SET 
  title = convert_from(convert_to(title::text, 'UTF8'), 'UTF8'),
  content = convert_from(convert_to(content::text, 'UTF8'), 'UTF8'),
  updated_at = NOW();