/*
  # Fix character encoding for news articles
  
  1. Changes
    - Add function to properly handle UTF-8 content
    - Add trigger to ensure UTF-8 encoding on insert/update
    - Fix existing content encoding issues
*/

-- Create function to properly handle UTF-8 content
CREATE OR REPLACE FUNCTION fix_encoding(text_to_fix text) 
RETURNS text AS $$
BEGIN
  -- Convert HTML entities to proper UTF-8 characters
  RETURN regexp_replace(
    regexp_replace(
      regexp_replace(
        regexp_replace(
          regexp_replace(
            regexp_replace(text_to_fix,
              '&oslash;', 'ø', 'g'),
            '&aelig;', 'æ', 'g'),
          '&aring;', 'å', 'g'),
        '&Oslash;', 'Ø', 'g'),
      '&Aelig;', 'Æ', 'g'),
    '&Aring;', 'Å', 'g');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create trigger function to ensure proper encoding
CREATE OR REPLACE FUNCTION ensure_proper_encoding()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.title IS NOT NULL THEN
    NEW.title := fix_encoding(NEW.title);
  END IF;
  IF NEW.content IS NOT NULL THEN
    NEW.content := fix_encoding(NEW.content);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to ensure proper encoding on insert/update
DROP TRIGGER IF EXISTS ensure_news_encoding ON news_articles;
CREATE TRIGGER ensure_news_encoding
  BEFORE INSERT OR UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_proper_encoding();

-- Fix existing content
UPDATE news_articles 
SET 
  title = fix_encoding(title),
  content = fix_encoding(content),
  updated_at = NOW()
WHERE 
  title LIKE '%&%' OR 
  content LIKE '%&%';