/*
  # Fix character encoding in news articles
  
  1. Changes
    - Create function to convert HTML entities to UTF-8 characters
    - Add trigger to ensure proper encoding on insert/update
    - Fix existing content by removing HTML tags and converting entities
*/

-- Create function to properly handle text content
CREATE OR REPLACE FUNCTION clean_content(text_to_clean text) 
RETURNS text AS $$
BEGIN
  -- First remove any HTML tags
  text_to_clean := regexp_replace(text_to_clean, '<[^>]*>', '', 'g');
  
  -- Then convert common HTML entities to proper characters
  RETURN regexp_replace(
    regexp_replace(
      regexp_replace(
        regexp_replace(
          regexp_replace(
            regexp_replace(
              regexp_replace(
                regexp_replace(
                  regexp_replace(
                    regexp_replace(
                      regexp_replace(
                        regexp_replace(text_to_clean,
                          '&oslash;', 'ø', 'g'),
                        '&aelig;', 'æ', 'g'),
                      '&aring;', 'å', 'g'),
                    '&Oslash;', 'Ø', 'g'),
                  '&Aelig;', 'Æ', 'g'),
                '&Aring;', 'Å', 'g'),
              '&ndash;', '–', 'g'),
            '&mdash;', '—', 'g'),
          '&nbsp;', ' ', 'g'),
        '&amp;', '&', 'g'),
      '&lt;', '<', 'g'),
    '&gt;', '>', 'g');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create trigger function to ensure proper content
CREATE OR REPLACE FUNCTION ensure_proper_encoding()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.title IS NOT NULL THEN
    NEW.title := clean_content(NEW.title);
  END IF;
  IF NEW.content IS NOT NULL THEN
    NEW.content := clean_content(NEW.content);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to ensure proper encoding on insert/update
DROP TRIGGER IF EXISTS ensure_news_encoding ON news_articles;
CREATE TRIGGER ensure_news_encoding
  BEFORE INSERT OR UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_proper_encoding();

-- Fix existing content
UPDATE news_articles 
SET 
  title = clean_content(title),
  content = clean_content(content),
  updated_at = NOW()
WHERE 
  title LIKE '%<%' OR 
  title LIKE '%&%' OR
  content LIKE '%<%' OR 
  content LIKE '%&%';