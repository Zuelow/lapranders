/*
  # Add visitor tracking table
  
  1. New Tables
    - visitor_sessions: Track unique visitors and show welcome message
    
  2. Security
    - Enable RLS
    - Allow anonymous inserts
    - Allow reading own sessions
*/

CREATE TABLE visitor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text NOT NULL,
  user_agent text,
  first_visit_at timestamptz DEFAULT now(),
  last_visit_at timestamptz DEFAULT now(),
  visit_count integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE visitor_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable anonymous insert"
ON visitor_sessions FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Enable reading own sessions"
ON visitor_sessions FOR SELECT
TO public
USING (ip_address = current_setting('request.headers')::json->>'x-real-ip');