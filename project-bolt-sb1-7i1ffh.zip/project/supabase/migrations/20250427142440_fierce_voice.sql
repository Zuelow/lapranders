/*
  # Create design settings table
  
  1. New Tables
    - design_settings: Stores website design customization settings
    
  2. Security
    - Enable RLS
    - Add policies for admin access
*/

CREATE TABLE design_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE design_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow admins to manage design settings"
ON design_settings
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

-- Create updated_at trigger
CREATE TRIGGER update_design_settings_updated_at
  BEFORE UPDATE ON design_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Create audit trigger
CREATE TRIGGER audit_design_settings
  AFTER INSERT OR UPDATE OR DELETE ON design_settings
  FOR EACH ROW
  EXECUTE FUNCTION audit_log_change();