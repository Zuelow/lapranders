/*
  # Create design settings table
  
  1. New Tables
    - `design_settings`
      - `id` (uuid, primary key)
      - `settings` (jsonb, stores carousel images and other design settings)
      - `updated_by` (uuid, references auth.users)
      - `updated_at` (timestamp with time zone)
      - `created_at` (timestamp with time zone)
  
  2. Security
    - Enable RLS on design_settings table
    - Add policies for:
      - Public read access (everyone can view settings)
      - Authenticated users can update settings
*/

-- Create the design_settings table
CREATE TABLE IF NOT EXISTS design_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_by uuid REFERENCES auth.users(id),
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE design_settings ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
  ON design_settings
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated users to update settings
CREATE POLICY "Allow authenticated users to update settings"
  ON design_settings
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert default settings if table is empty
INSERT INTO design_settings (settings)
SELECT '{
  "carouselImages": [
    {
      "url": "https://i.ibb.co/8bDrQK2/Dialogmoede-aalborg.jpg",
      "alt": "LAP Aalborg Dialogmøde",
      "caption": "LAP Aalborg Dialogmøde"
    },
    {
      "url": "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?auto=format&fit=crop&q=80",
      "alt": "Mental Health Support",
      "caption": "Mental Sundhed"
    },
    {
      "url": "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80",
      "alt": "Community Meeting",
      "caption": "Fællesskabsmøde"
    },
    {
      "url": "https://images.unsplash.com/photo-1573497491765-dccce02b29df?auto=format&fit=crop&q=80",
      "alt": "Peer Support",
      "caption": "Peer Støtte"
    },
    {
      "url": "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80",
      "alt": "Group Therapy",
      "caption": "Gruppeterapi"
    }
  ]
}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM design_settings);